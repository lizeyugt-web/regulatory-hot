
/**
 * Client
**/

import * as runtime from '@prisma/client/runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model Event
 * 
 */
export type Event = $Result.DefaultSelection<Prisma.$EventPayload>
/**
 * Model Source
 * 
 */
export type Source = $Result.DefaultSelection<Prisma.$SourcePayload>
/**
 * Model CrawlLog
 * 
 */
export type CrawlLog = $Result.DefaultSelection<Prisma.$CrawlLogPayload>
/**
 * Model AiAnalysis
 * 
 */
export type AiAnalysis = $Result.DefaultSelection<Prisma.$AiAnalysisPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Events
 * const events = await prisma.event.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Events
   * const events = await prisma.event.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.event`: Exposes CRUD operations for the **Event** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Events
    * const events = await prisma.event.findMany()
    * ```
    */
  get event(): Prisma.EventDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.source`: Exposes CRUD operations for the **Source** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Sources
    * const sources = await prisma.source.findMany()
    * ```
    */
  get source(): Prisma.SourceDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.crawlLog`: Exposes CRUD operations for the **CrawlLog** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CrawlLogs
    * const crawlLogs = await prisma.crawlLog.findMany()
    * ```
    */
  get crawlLog(): Prisma.CrawlLogDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.aiAnalysis`: Exposes CRUD operations for the **AiAnalysis** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more AiAnalyses
    * const aiAnalyses = await prisma.aiAnalysis.findMany()
    * ```
    */
  get aiAnalysis(): Prisma.AiAnalysisDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    Event: 'Event',
    Source: 'Source',
    CrawlLog: 'CrawlLog',
    AiAnalysis: 'AiAnalysis'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "event" | "source" | "crawlLog" | "aiAnalysis"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      Event: {
        payload: Prisma.$EventPayload<ExtArgs>
        fields: Prisma.EventFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EventFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EventFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          findFirst: {
            args: Prisma.EventFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EventFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          findMany: {
            args: Prisma.EventFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>[]
          }
          create: {
            args: Prisma.EventCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          createMany: {
            args: Prisma.EventCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.EventCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>[]
          }
          delete: {
            args: Prisma.EventDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          update: {
            args: Prisma.EventUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          deleteMany: {
            args: Prisma.EventDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EventUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.EventUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>[]
          }
          upsert: {
            args: Prisma.EventUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EventPayload>
          }
          aggregate: {
            args: Prisma.EventAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEvent>
          }
          groupBy: {
            args: Prisma.EventGroupByArgs<ExtArgs>
            result: $Utils.Optional<EventGroupByOutputType>[]
          }
          count: {
            args: Prisma.EventCountArgs<ExtArgs>
            result: $Utils.Optional<EventCountAggregateOutputType> | number
          }
        }
      }
      Source: {
        payload: Prisma.$SourcePayload<ExtArgs>
        fields: Prisma.SourceFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SourceFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SourceFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          findFirst: {
            args: Prisma.SourceFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SourceFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          findMany: {
            args: Prisma.SourceFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>[]
          }
          create: {
            args: Prisma.SourceCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          createMany: {
            args: Prisma.SourceCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SourceCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>[]
          }
          delete: {
            args: Prisma.SourceDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          update: {
            args: Prisma.SourceUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          deleteMany: {
            args: Prisma.SourceDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SourceUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SourceUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>[]
          }
          upsert: {
            args: Prisma.SourceUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SourcePayload>
          }
          aggregate: {
            args: Prisma.SourceAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSource>
          }
          groupBy: {
            args: Prisma.SourceGroupByArgs<ExtArgs>
            result: $Utils.Optional<SourceGroupByOutputType>[]
          }
          count: {
            args: Prisma.SourceCountArgs<ExtArgs>
            result: $Utils.Optional<SourceCountAggregateOutputType> | number
          }
        }
      }
      CrawlLog: {
        payload: Prisma.$CrawlLogPayload<ExtArgs>
        fields: Prisma.CrawlLogFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CrawlLogFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CrawlLogFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          findFirst: {
            args: Prisma.CrawlLogFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CrawlLogFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          findMany: {
            args: Prisma.CrawlLogFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>[]
          }
          create: {
            args: Prisma.CrawlLogCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          createMany: {
            args: Prisma.CrawlLogCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CrawlLogCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>[]
          }
          delete: {
            args: Prisma.CrawlLogDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          update: {
            args: Prisma.CrawlLogUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          deleteMany: {
            args: Prisma.CrawlLogDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CrawlLogUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CrawlLogUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>[]
          }
          upsert: {
            args: Prisma.CrawlLogUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CrawlLogPayload>
          }
          aggregate: {
            args: Prisma.CrawlLogAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCrawlLog>
          }
          groupBy: {
            args: Prisma.CrawlLogGroupByArgs<ExtArgs>
            result: $Utils.Optional<CrawlLogGroupByOutputType>[]
          }
          count: {
            args: Prisma.CrawlLogCountArgs<ExtArgs>
            result: $Utils.Optional<CrawlLogCountAggregateOutputType> | number
          }
        }
      }
      AiAnalysis: {
        payload: Prisma.$AiAnalysisPayload<ExtArgs>
        fields: Prisma.AiAnalysisFieldRefs
        operations: {
          findUnique: {
            args: Prisma.AiAnalysisFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.AiAnalysisFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          findFirst: {
            args: Prisma.AiAnalysisFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.AiAnalysisFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          findMany: {
            args: Prisma.AiAnalysisFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>[]
          }
          create: {
            args: Prisma.AiAnalysisCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          createMany: {
            args: Prisma.AiAnalysisCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.AiAnalysisCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>[]
          }
          delete: {
            args: Prisma.AiAnalysisDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          update: {
            args: Prisma.AiAnalysisUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          deleteMany: {
            args: Prisma.AiAnalysisDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.AiAnalysisUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.AiAnalysisUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>[]
          }
          upsert: {
            args: Prisma.AiAnalysisUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$AiAnalysisPayload>
          }
          aggregate: {
            args: Prisma.AiAnalysisAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateAiAnalysis>
          }
          groupBy: {
            args: Prisma.AiAnalysisGroupByArgs<ExtArgs>
            result: $Utils.Optional<AiAnalysisGroupByOutputType>[]
          }
          count: {
            args: Prisma.AiAnalysisCountArgs<ExtArgs>
            result: $Utils.Optional<AiAnalysisCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    event?: EventOmit
    source?: SourceOmit
    crawlLog?: CrawlLogOmit
    aiAnalysis?: AiAnalysisOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */



  /**
   * Models
   */

  /**
   * Model Event
   */

  export type AggregateEvent = {
    _count: EventCountAggregateOutputType | null
    _avg: EventAvgAggregateOutputType | null
    _sum: EventSumAggregateOutputType | null
    _min: EventMinAggregateOutputType | null
    _max: EventMaxAggregateOutputType | null
  }

  export type EventAvgAggregateOutputType = {
    finalScore: number | null
    importance: number | null
    aiCost: number | null
    selected: number | null
    isLead: number | null
    isSocial: number | null
    readCount: number | null
    likeCount: number | null
    clusterSize: number | null
  }

  export type EventSumAggregateOutputType = {
    finalScore: number | null
    importance: number | null
    aiCost: number | null
    selected: number | null
    isLead: number | null
    isSocial: number | null
    readCount: number | null
    likeCount: number | null
    clusterSize: number | null
  }

  export type EventMinAggregateOutputType = {
    id: string | null
    rawItemId: string | null
    titleOriginal: string | null
    titleCn: string | null
    titleLang: string | null
    summaryOriginal: string | null
    summaryCn: string | null
    contentOriginal: string | null
    contentCn: string | null
    contentHint: string | null
    contentType: string | null
    url: string | null
    permalink: string | null
    sourceId: string | null
    sourceName: string | null
    sourceLevel: string | null
    sourceCountry: string | null
    sourceFeed: string | null
    sourceDesc: string | null
    category: string | null
    subCategory: string | null
    tags: string | null
    affectedRegions: string | null
    scores: string | null
    finalScore: number | null
    importance: number | null
    aiStatus: string | null
    aiModel: string | null
    aiTranslateModel: string | null
    aiReason: string | null
    aiCost: number | null
    aiAnalyzedAt: string | null
    selected: number | null
    isLead: number | null
    publishedAt: string | null
    crawledAt: string | null
    createdAt: string | null
    updatedAt: string | null
    isSocial: number | null
    readCount: number | null
    likeCount: number | null
    coverUrl: string | null
    clusterId: string | null
    clusterSize: number | null
  }

  export type EventMaxAggregateOutputType = {
    id: string | null
    rawItemId: string | null
    titleOriginal: string | null
    titleCn: string | null
    titleLang: string | null
    summaryOriginal: string | null
    summaryCn: string | null
    contentOriginal: string | null
    contentCn: string | null
    contentHint: string | null
    contentType: string | null
    url: string | null
    permalink: string | null
    sourceId: string | null
    sourceName: string | null
    sourceLevel: string | null
    sourceCountry: string | null
    sourceFeed: string | null
    sourceDesc: string | null
    category: string | null
    subCategory: string | null
    tags: string | null
    affectedRegions: string | null
    scores: string | null
    finalScore: number | null
    importance: number | null
    aiStatus: string | null
    aiModel: string | null
    aiTranslateModel: string | null
    aiReason: string | null
    aiCost: number | null
    aiAnalyzedAt: string | null
    selected: number | null
    isLead: number | null
    publishedAt: string | null
    crawledAt: string | null
    createdAt: string | null
    updatedAt: string | null
    isSocial: number | null
    readCount: number | null
    likeCount: number | null
    coverUrl: string | null
    clusterId: string | null
    clusterSize: number | null
  }

  export type EventCountAggregateOutputType = {
    id: number
    rawItemId: number
    titleOriginal: number
    titleCn: number
    titleLang: number
    summaryOriginal: number
    summaryCn: number
    contentOriginal: number
    contentCn: number
    contentHint: number
    contentType: number
    url: number
    permalink: number
    sourceId: number
    sourceName: number
    sourceLevel: number
    sourceCountry: number
    sourceFeed: number
    sourceDesc: number
    category: number
    subCategory: number
    tags: number
    affectedRegions: number
    scores: number
    finalScore: number
    importance: number
    aiStatus: number
    aiModel: number
    aiTranslateModel: number
    aiReason: number
    aiCost: number
    aiAnalyzedAt: number
    selected: number
    isLead: number
    publishedAt: number
    crawledAt: number
    createdAt: number
    updatedAt: number
    isSocial: number
    readCount: number
    likeCount: number
    coverUrl: number
    clusterId: number
    clusterSize: number
    _all: number
  }


  export type EventAvgAggregateInputType = {
    finalScore?: true
    importance?: true
    aiCost?: true
    selected?: true
    isLead?: true
    isSocial?: true
    readCount?: true
    likeCount?: true
    clusterSize?: true
  }

  export type EventSumAggregateInputType = {
    finalScore?: true
    importance?: true
    aiCost?: true
    selected?: true
    isLead?: true
    isSocial?: true
    readCount?: true
    likeCount?: true
    clusterSize?: true
  }

  export type EventMinAggregateInputType = {
    id?: true
    rawItemId?: true
    titleOriginal?: true
    titleCn?: true
    titleLang?: true
    summaryOriginal?: true
    summaryCn?: true
    contentOriginal?: true
    contentCn?: true
    contentHint?: true
    contentType?: true
    url?: true
    permalink?: true
    sourceId?: true
    sourceName?: true
    sourceLevel?: true
    sourceCountry?: true
    sourceFeed?: true
    sourceDesc?: true
    category?: true
    subCategory?: true
    tags?: true
    affectedRegions?: true
    scores?: true
    finalScore?: true
    importance?: true
    aiStatus?: true
    aiModel?: true
    aiTranslateModel?: true
    aiReason?: true
    aiCost?: true
    aiAnalyzedAt?: true
    selected?: true
    isLead?: true
    publishedAt?: true
    crawledAt?: true
    createdAt?: true
    updatedAt?: true
    isSocial?: true
    readCount?: true
    likeCount?: true
    coverUrl?: true
    clusterId?: true
    clusterSize?: true
  }

  export type EventMaxAggregateInputType = {
    id?: true
    rawItemId?: true
    titleOriginal?: true
    titleCn?: true
    titleLang?: true
    summaryOriginal?: true
    summaryCn?: true
    contentOriginal?: true
    contentCn?: true
    contentHint?: true
    contentType?: true
    url?: true
    permalink?: true
    sourceId?: true
    sourceName?: true
    sourceLevel?: true
    sourceCountry?: true
    sourceFeed?: true
    sourceDesc?: true
    category?: true
    subCategory?: true
    tags?: true
    affectedRegions?: true
    scores?: true
    finalScore?: true
    importance?: true
    aiStatus?: true
    aiModel?: true
    aiTranslateModel?: true
    aiReason?: true
    aiCost?: true
    aiAnalyzedAt?: true
    selected?: true
    isLead?: true
    publishedAt?: true
    crawledAt?: true
    createdAt?: true
    updatedAt?: true
    isSocial?: true
    readCount?: true
    likeCount?: true
    coverUrl?: true
    clusterId?: true
    clusterSize?: true
  }

  export type EventCountAggregateInputType = {
    id?: true
    rawItemId?: true
    titleOriginal?: true
    titleCn?: true
    titleLang?: true
    summaryOriginal?: true
    summaryCn?: true
    contentOriginal?: true
    contentCn?: true
    contentHint?: true
    contentType?: true
    url?: true
    permalink?: true
    sourceId?: true
    sourceName?: true
    sourceLevel?: true
    sourceCountry?: true
    sourceFeed?: true
    sourceDesc?: true
    category?: true
    subCategory?: true
    tags?: true
    affectedRegions?: true
    scores?: true
    finalScore?: true
    importance?: true
    aiStatus?: true
    aiModel?: true
    aiTranslateModel?: true
    aiReason?: true
    aiCost?: true
    aiAnalyzedAt?: true
    selected?: true
    isLead?: true
    publishedAt?: true
    crawledAt?: true
    createdAt?: true
    updatedAt?: true
    isSocial?: true
    readCount?: true
    likeCount?: true
    coverUrl?: true
    clusterId?: true
    clusterSize?: true
    _all?: true
  }

  export type EventAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Event to aggregate.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Events
    **/
    _count?: true | EventCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EventAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EventSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EventMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EventMaxAggregateInputType
  }

  export type GetEventAggregateType<T extends EventAggregateArgs> = {
        [P in keyof T & keyof AggregateEvent]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEvent[P]>
      : GetScalarType<T[P], AggregateEvent[P]>
  }




  export type EventGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EventWhereInput
    orderBy?: EventOrderByWithAggregationInput | EventOrderByWithAggregationInput[]
    by: EventScalarFieldEnum[] | EventScalarFieldEnum
    having?: EventScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EventCountAggregateInputType | true
    _avg?: EventAvgAggregateInputType
    _sum?: EventSumAggregateInputType
    _min?: EventMinAggregateInputType
    _max?: EventMaxAggregateInputType
  }

  export type EventGroupByOutputType = {
    id: string
    rawItemId: string
    titleOriginal: string
    titleCn: string
    titleLang: string
    summaryOriginal: string
    summaryCn: string
    contentOriginal: string | null
    contentCn: string | null
    contentHint: string | null
    contentType: string
    url: string
    permalink: string
    sourceId: string
    sourceName: string
    sourceLevel: string
    sourceCountry: string
    sourceFeed: string
    sourceDesc: string
    category: string
    subCategory: string
    tags: string
    affectedRegions: string
    scores: string
    finalScore: number
    importance: number
    aiStatus: string
    aiModel: string
    aiTranslateModel: string
    aiReason: string
    aiCost: number
    aiAnalyzedAt: string | null
    selected: number
    isLead: number
    publishedAt: string
    crawledAt: string
    createdAt: string
    updatedAt: string
    isSocial: number
    readCount: number
    likeCount: number
    coverUrl: string
    clusterId: string | null
    clusterSize: number
    _count: EventCountAggregateOutputType | null
    _avg: EventAvgAggregateOutputType | null
    _sum: EventSumAggregateOutputType | null
    _min: EventMinAggregateOutputType | null
    _max: EventMaxAggregateOutputType | null
  }

  type GetEventGroupByPayload<T extends EventGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EventGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EventGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EventGroupByOutputType[P]>
            : GetScalarType<T[P], EventGroupByOutputType[P]>
        }
      >
    >


  export type EventSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rawItemId?: boolean
    titleOriginal?: boolean
    titleCn?: boolean
    titleLang?: boolean
    summaryOriginal?: boolean
    summaryCn?: boolean
    contentOriginal?: boolean
    contentCn?: boolean
    contentHint?: boolean
    contentType?: boolean
    url?: boolean
    permalink?: boolean
    sourceId?: boolean
    sourceName?: boolean
    sourceLevel?: boolean
    sourceCountry?: boolean
    sourceFeed?: boolean
    sourceDesc?: boolean
    category?: boolean
    subCategory?: boolean
    tags?: boolean
    affectedRegions?: boolean
    scores?: boolean
    finalScore?: boolean
    importance?: boolean
    aiStatus?: boolean
    aiModel?: boolean
    aiTranslateModel?: boolean
    aiReason?: boolean
    aiCost?: boolean
    aiAnalyzedAt?: boolean
    selected?: boolean
    isLead?: boolean
    publishedAt?: boolean
    crawledAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isSocial?: boolean
    readCount?: boolean
    likeCount?: boolean
    coverUrl?: boolean
    clusterId?: boolean
    clusterSize?: boolean
  }, ExtArgs["result"]["event"]>

  export type EventSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rawItemId?: boolean
    titleOriginal?: boolean
    titleCn?: boolean
    titleLang?: boolean
    summaryOriginal?: boolean
    summaryCn?: boolean
    contentOriginal?: boolean
    contentCn?: boolean
    contentHint?: boolean
    contentType?: boolean
    url?: boolean
    permalink?: boolean
    sourceId?: boolean
    sourceName?: boolean
    sourceLevel?: boolean
    sourceCountry?: boolean
    sourceFeed?: boolean
    sourceDesc?: boolean
    category?: boolean
    subCategory?: boolean
    tags?: boolean
    affectedRegions?: boolean
    scores?: boolean
    finalScore?: boolean
    importance?: boolean
    aiStatus?: boolean
    aiModel?: boolean
    aiTranslateModel?: boolean
    aiReason?: boolean
    aiCost?: boolean
    aiAnalyzedAt?: boolean
    selected?: boolean
    isLead?: boolean
    publishedAt?: boolean
    crawledAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isSocial?: boolean
    readCount?: boolean
    likeCount?: boolean
    coverUrl?: boolean
    clusterId?: boolean
    clusterSize?: boolean
  }, ExtArgs["result"]["event"]>

  export type EventSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    rawItemId?: boolean
    titleOriginal?: boolean
    titleCn?: boolean
    titleLang?: boolean
    summaryOriginal?: boolean
    summaryCn?: boolean
    contentOriginal?: boolean
    contentCn?: boolean
    contentHint?: boolean
    contentType?: boolean
    url?: boolean
    permalink?: boolean
    sourceId?: boolean
    sourceName?: boolean
    sourceLevel?: boolean
    sourceCountry?: boolean
    sourceFeed?: boolean
    sourceDesc?: boolean
    category?: boolean
    subCategory?: boolean
    tags?: boolean
    affectedRegions?: boolean
    scores?: boolean
    finalScore?: boolean
    importance?: boolean
    aiStatus?: boolean
    aiModel?: boolean
    aiTranslateModel?: boolean
    aiReason?: boolean
    aiCost?: boolean
    aiAnalyzedAt?: boolean
    selected?: boolean
    isLead?: boolean
    publishedAt?: boolean
    crawledAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isSocial?: boolean
    readCount?: boolean
    likeCount?: boolean
    coverUrl?: boolean
    clusterId?: boolean
    clusterSize?: boolean
  }, ExtArgs["result"]["event"]>

  export type EventSelectScalar = {
    id?: boolean
    rawItemId?: boolean
    titleOriginal?: boolean
    titleCn?: boolean
    titleLang?: boolean
    summaryOriginal?: boolean
    summaryCn?: boolean
    contentOriginal?: boolean
    contentCn?: boolean
    contentHint?: boolean
    contentType?: boolean
    url?: boolean
    permalink?: boolean
    sourceId?: boolean
    sourceName?: boolean
    sourceLevel?: boolean
    sourceCountry?: boolean
    sourceFeed?: boolean
    sourceDesc?: boolean
    category?: boolean
    subCategory?: boolean
    tags?: boolean
    affectedRegions?: boolean
    scores?: boolean
    finalScore?: boolean
    importance?: boolean
    aiStatus?: boolean
    aiModel?: boolean
    aiTranslateModel?: boolean
    aiReason?: boolean
    aiCost?: boolean
    aiAnalyzedAt?: boolean
    selected?: boolean
    isLead?: boolean
    publishedAt?: boolean
    crawledAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    isSocial?: boolean
    readCount?: boolean
    likeCount?: boolean
    coverUrl?: boolean
    clusterId?: boolean
    clusterSize?: boolean
  }

  export type EventOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "rawItemId" | "titleOriginal" | "titleCn" | "titleLang" | "summaryOriginal" | "summaryCn" | "contentOriginal" | "contentCn" | "contentHint" | "contentType" | "url" | "permalink" | "sourceId" | "sourceName" | "sourceLevel" | "sourceCountry" | "sourceFeed" | "sourceDesc" | "category" | "subCategory" | "tags" | "affectedRegions" | "scores" | "finalScore" | "importance" | "aiStatus" | "aiModel" | "aiTranslateModel" | "aiReason" | "aiCost" | "aiAnalyzedAt" | "selected" | "isLead" | "publishedAt" | "crawledAt" | "createdAt" | "updatedAt" | "isSocial" | "readCount" | "likeCount" | "coverUrl" | "clusterId" | "clusterSize", ExtArgs["result"]["event"]>

  export type $EventPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Event"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      rawItemId: string
      titleOriginal: string
      titleCn: string
      titleLang: string
      summaryOriginal: string
      summaryCn: string
      contentOriginal: string | null
      contentCn: string | null
      contentHint: string | null
      contentType: string
      url: string
      permalink: string
      sourceId: string
      sourceName: string
      sourceLevel: string
      sourceCountry: string
      sourceFeed: string
      sourceDesc: string
      category: string
      subCategory: string
      tags: string
      affectedRegions: string
      scores: string
      finalScore: number
      importance: number
      aiStatus: string
      aiModel: string
      aiTranslateModel: string
      aiReason: string
      aiCost: number
      aiAnalyzedAt: string | null
      selected: number
      isLead: number
      publishedAt: string
      crawledAt: string
      createdAt: string
      updatedAt: string
      isSocial: number
      readCount: number
      likeCount: number
      coverUrl: string
      clusterId: string | null
      clusterSize: number
    }, ExtArgs["result"]["event"]>
    composites: {}
  }

  type EventGetPayload<S extends boolean | null | undefined | EventDefaultArgs> = $Result.GetResult<Prisma.$EventPayload, S>

  type EventCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EventFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EventCountAggregateInputType | true
    }

  export interface EventDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Event'], meta: { name: 'Event' } }
    /**
     * Find zero or one Event that matches the filter.
     * @param {EventFindUniqueArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EventFindUniqueArgs>(args: SelectSubset<T, EventFindUniqueArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Event that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EventFindUniqueOrThrowArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EventFindUniqueOrThrowArgs>(args: SelectSubset<T, EventFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Event that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindFirstArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EventFindFirstArgs>(args?: SelectSubset<T, EventFindFirstArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Event that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindFirstOrThrowArgs} args - Arguments to find a Event
     * @example
     * // Get one Event
     * const event = await prisma.event.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EventFindFirstOrThrowArgs>(args?: SelectSubset<T, EventFindFirstOrThrowArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Events that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Events
     * const events = await prisma.event.findMany()
     * 
     * // Get first 10 Events
     * const events = await prisma.event.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const eventWithIdOnly = await prisma.event.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EventFindManyArgs>(args?: SelectSubset<T, EventFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Event.
     * @param {EventCreateArgs} args - Arguments to create a Event.
     * @example
     * // Create one Event
     * const Event = await prisma.event.create({
     *   data: {
     *     // ... data to create a Event
     *   }
     * })
     * 
     */
    create<T extends EventCreateArgs>(args: SelectSubset<T, EventCreateArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Events.
     * @param {EventCreateManyArgs} args - Arguments to create many Events.
     * @example
     * // Create many Events
     * const event = await prisma.event.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EventCreateManyArgs>(args?: SelectSubset<T, EventCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Events and returns the data saved in the database.
     * @param {EventCreateManyAndReturnArgs} args - Arguments to create many Events.
     * @example
     * // Create many Events
     * const event = await prisma.event.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Events and only return the `id`
     * const eventWithIdOnly = await prisma.event.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends EventCreateManyAndReturnArgs>(args?: SelectSubset<T, EventCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Event.
     * @param {EventDeleteArgs} args - Arguments to delete one Event.
     * @example
     * // Delete one Event
     * const Event = await prisma.event.delete({
     *   where: {
     *     // ... filter to delete one Event
     *   }
     * })
     * 
     */
    delete<T extends EventDeleteArgs>(args: SelectSubset<T, EventDeleteArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Event.
     * @param {EventUpdateArgs} args - Arguments to update one Event.
     * @example
     * // Update one Event
     * const event = await prisma.event.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EventUpdateArgs>(args: SelectSubset<T, EventUpdateArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Events.
     * @param {EventDeleteManyArgs} args - Arguments to filter Events to delete.
     * @example
     * // Delete a few Events
     * const { count } = await prisma.event.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EventDeleteManyArgs>(args?: SelectSubset<T, EventDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Events.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Events
     * const event = await prisma.event.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EventUpdateManyArgs>(args: SelectSubset<T, EventUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Events and returns the data updated in the database.
     * @param {EventUpdateManyAndReturnArgs} args - Arguments to update many Events.
     * @example
     * // Update many Events
     * const event = await prisma.event.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Events and only return the `id`
     * const eventWithIdOnly = await prisma.event.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends EventUpdateManyAndReturnArgs>(args: SelectSubset<T, EventUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Event.
     * @param {EventUpsertArgs} args - Arguments to update or create a Event.
     * @example
     * // Update or create a Event
     * const event = await prisma.event.upsert({
     *   create: {
     *     // ... data to create a Event
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Event we want to update
     *   }
     * })
     */
    upsert<T extends EventUpsertArgs>(args: SelectSubset<T, EventUpsertArgs<ExtArgs>>): Prisma__EventClient<$Result.GetResult<Prisma.$EventPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Events.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventCountArgs} args - Arguments to filter Events to count.
     * @example
     * // Count the number of Events
     * const count = await prisma.event.count({
     *   where: {
     *     // ... the filter for the Events we want to count
     *   }
     * })
    **/
    count<T extends EventCountArgs>(
      args?: Subset<T, EventCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EventCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Event.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EventAggregateArgs>(args: Subset<T, EventAggregateArgs>): Prisma.PrismaPromise<GetEventAggregateType<T>>

    /**
     * Group by Event.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EventGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EventGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EventGroupByArgs['orderBy'] }
        : { orderBy?: EventGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EventGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEventGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Event model
   */
  readonly fields: EventFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Event.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EventClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Event model
   */
  interface EventFieldRefs {
    readonly id: FieldRef<"Event", 'String'>
    readonly rawItemId: FieldRef<"Event", 'String'>
    readonly titleOriginal: FieldRef<"Event", 'String'>
    readonly titleCn: FieldRef<"Event", 'String'>
    readonly titleLang: FieldRef<"Event", 'String'>
    readonly summaryOriginal: FieldRef<"Event", 'String'>
    readonly summaryCn: FieldRef<"Event", 'String'>
    readonly contentOriginal: FieldRef<"Event", 'String'>
    readonly contentCn: FieldRef<"Event", 'String'>
    readonly contentHint: FieldRef<"Event", 'String'>
    readonly contentType: FieldRef<"Event", 'String'>
    readonly url: FieldRef<"Event", 'String'>
    readonly permalink: FieldRef<"Event", 'String'>
    readonly sourceId: FieldRef<"Event", 'String'>
    readonly sourceName: FieldRef<"Event", 'String'>
    readonly sourceLevel: FieldRef<"Event", 'String'>
    readonly sourceCountry: FieldRef<"Event", 'String'>
    readonly sourceFeed: FieldRef<"Event", 'String'>
    readonly sourceDesc: FieldRef<"Event", 'String'>
    readonly category: FieldRef<"Event", 'String'>
    readonly subCategory: FieldRef<"Event", 'String'>
    readonly tags: FieldRef<"Event", 'String'>
    readonly affectedRegions: FieldRef<"Event", 'String'>
    readonly scores: FieldRef<"Event", 'String'>
    readonly finalScore: FieldRef<"Event", 'Float'>
    readonly importance: FieldRef<"Event", 'Int'>
    readonly aiStatus: FieldRef<"Event", 'String'>
    readonly aiModel: FieldRef<"Event", 'String'>
    readonly aiTranslateModel: FieldRef<"Event", 'String'>
    readonly aiReason: FieldRef<"Event", 'String'>
    readonly aiCost: FieldRef<"Event", 'Float'>
    readonly aiAnalyzedAt: FieldRef<"Event", 'String'>
    readonly selected: FieldRef<"Event", 'Int'>
    readonly isLead: FieldRef<"Event", 'Int'>
    readonly publishedAt: FieldRef<"Event", 'String'>
    readonly crawledAt: FieldRef<"Event", 'String'>
    readonly createdAt: FieldRef<"Event", 'String'>
    readonly updatedAt: FieldRef<"Event", 'String'>
    readonly isSocial: FieldRef<"Event", 'Int'>
    readonly readCount: FieldRef<"Event", 'Int'>
    readonly likeCount: FieldRef<"Event", 'Int'>
    readonly coverUrl: FieldRef<"Event", 'String'>
    readonly clusterId: FieldRef<"Event", 'String'>
    readonly clusterSize: FieldRef<"Event", 'Int'>
  }
    

  // Custom InputTypes
  /**
   * Event findUnique
   */
  export type EventFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event findUniqueOrThrow
   */
  export type EventFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event findFirst
   */
  export type EventFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Events.
     */
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event findFirstOrThrow
   */
  export type EventFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter, which Event to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Events.
     */
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event findMany
   */
  export type EventFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter, which Events to fetch.
     */
    where?: EventWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Events to fetch.
     */
    orderBy?: EventOrderByWithRelationInput | EventOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Events.
     */
    cursor?: EventWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Events from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Events.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Events.
     */
    distinct?: EventScalarFieldEnum | EventScalarFieldEnum[]
  }

  /**
   * Event create
   */
  export type EventCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * The data needed to create a Event.
     */
    data: XOR<EventCreateInput, EventUncheckedCreateInput>
  }

  /**
   * Event createMany
   */
  export type EventCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Events.
     */
    data: EventCreateManyInput | EventCreateManyInput[]
  }

  /**
   * Event createManyAndReturn
   */
  export type EventCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * The data used to create many Events.
     */
    data: EventCreateManyInput | EventCreateManyInput[]
  }

  /**
   * Event update
   */
  export type EventUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * The data needed to update a Event.
     */
    data: XOR<EventUpdateInput, EventUncheckedUpdateInput>
    /**
     * Choose, which Event to update.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event updateMany
   */
  export type EventUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Events.
     */
    data: XOR<EventUpdateManyMutationInput, EventUncheckedUpdateManyInput>
    /**
     * Filter which Events to update
     */
    where?: EventWhereInput
    /**
     * Limit how many Events to update.
     */
    limit?: number
  }

  /**
   * Event updateManyAndReturn
   */
  export type EventUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * The data used to update Events.
     */
    data: XOR<EventUpdateManyMutationInput, EventUncheckedUpdateManyInput>
    /**
     * Filter which Events to update
     */
    where?: EventWhereInput
    /**
     * Limit how many Events to update.
     */
    limit?: number
  }

  /**
   * Event upsert
   */
  export type EventUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * The filter to search for the Event to update in case it exists.
     */
    where: EventWhereUniqueInput
    /**
     * In case the Event found by the `where` argument doesn't exist, create a new Event with this data.
     */
    create: XOR<EventCreateInput, EventUncheckedCreateInput>
    /**
     * In case the Event was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EventUpdateInput, EventUncheckedUpdateInput>
  }

  /**
   * Event delete
   */
  export type EventDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
    /**
     * Filter which Event to delete.
     */
    where: EventWhereUniqueInput
  }

  /**
   * Event deleteMany
   */
  export type EventDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Events to delete
     */
    where?: EventWhereInput
    /**
     * Limit how many Events to delete.
     */
    limit?: number
  }

  /**
   * Event without action
   */
  export type EventDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Event
     */
    select?: EventSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Event
     */
    omit?: EventOmit<ExtArgs> | null
  }


  /**
   * Model Source
   */

  export type AggregateSource = {
    _count: SourceCountAggregateOutputType | null
    _avg: SourceAvgAggregateOutputType | null
    _sum: SourceSumAggregateOutputType | null
    _min: SourceMinAggregateOutputType | null
    _max: SourceMaxAggregateOutputType | null
  }

  export type SourceAvgAggregateOutputType = {
    enabled: number | null
  }

  export type SourceSumAggregateOutputType = {
    enabled: number | null
  }

  export type SourceMinAggregateOutputType = {
    id: string | null
    name: string | null
    nameEn: string | null
    type: string | null
    country: string | null
    region: string | null
    level: string | null
    enabled: number | null
    endpoints: string | null
    config: string | null
    createdAt: string | null
    updatedAt: string | null
  }

  export type SourceMaxAggregateOutputType = {
    id: string | null
    name: string | null
    nameEn: string | null
    type: string | null
    country: string | null
    region: string | null
    level: string | null
    enabled: number | null
    endpoints: string | null
    config: string | null
    createdAt: string | null
    updatedAt: string | null
  }

  export type SourceCountAggregateOutputType = {
    id: number
    name: number
    nameEn: number
    type: number
    country: number
    region: number
    level: number
    enabled: number
    endpoints: number
    config: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SourceAvgAggregateInputType = {
    enabled?: true
  }

  export type SourceSumAggregateInputType = {
    enabled?: true
  }

  export type SourceMinAggregateInputType = {
    id?: true
    name?: true
    nameEn?: true
    type?: true
    country?: true
    region?: true
    level?: true
    enabled?: true
    endpoints?: true
    config?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SourceMaxAggregateInputType = {
    id?: true
    name?: true
    nameEn?: true
    type?: true
    country?: true
    region?: true
    level?: true
    enabled?: true
    endpoints?: true
    config?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SourceCountAggregateInputType = {
    id?: true
    name?: true
    nameEn?: true
    type?: true
    country?: true
    region?: true
    level?: true
    enabled?: true
    endpoints?: true
    config?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SourceAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Source to aggregate.
     */
    where?: SourceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sources to fetch.
     */
    orderBy?: SourceOrderByWithRelationInput | SourceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SourceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sources from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sources.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Sources
    **/
    _count?: true | SourceCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SourceAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SourceSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SourceMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SourceMaxAggregateInputType
  }

  export type GetSourceAggregateType<T extends SourceAggregateArgs> = {
        [P in keyof T & keyof AggregateSource]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSource[P]>
      : GetScalarType<T[P], AggregateSource[P]>
  }




  export type SourceGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SourceWhereInput
    orderBy?: SourceOrderByWithAggregationInput | SourceOrderByWithAggregationInput[]
    by: SourceScalarFieldEnum[] | SourceScalarFieldEnum
    having?: SourceScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SourceCountAggregateInputType | true
    _avg?: SourceAvgAggregateInputType
    _sum?: SourceSumAggregateInputType
    _min?: SourceMinAggregateInputType
    _max?: SourceMaxAggregateInputType
  }

  export type SourceGroupByOutputType = {
    id: string
    name: string
    nameEn: string
    type: string
    country: string
    region: string
    level: string
    enabled: number
    endpoints: string
    config: string
    createdAt: string
    updatedAt: string
    _count: SourceCountAggregateOutputType | null
    _avg: SourceAvgAggregateOutputType | null
    _sum: SourceSumAggregateOutputType | null
    _min: SourceMinAggregateOutputType | null
    _max: SourceMaxAggregateOutputType | null
  }

  type GetSourceGroupByPayload<T extends SourceGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SourceGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SourceGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SourceGroupByOutputType[P]>
            : GetScalarType<T[P], SourceGroupByOutputType[P]>
        }
      >
    >


  export type SourceSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    nameEn?: boolean
    type?: boolean
    country?: boolean
    region?: boolean
    level?: boolean
    enabled?: boolean
    endpoints?: boolean
    config?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["source"]>

  export type SourceSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    nameEn?: boolean
    type?: boolean
    country?: boolean
    region?: boolean
    level?: boolean
    enabled?: boolean
    endpoints?: boolean
    config?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["source"]>

  export type SourceSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    nameEn?: boolean
    type?: boolean
    country?: boolean
    region?: boolean
    level?: boolean
    enabled?: boolean
    endpoints?: boolean
    config?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["source"]>

  export type SourceSelectScalar = {
    id?: boolean
    name?: boolean
    nameEn?: boolean
    type?: boolean
    country?: boolean
    region?: boolean
    level?: boolean
    enabled?: boolean
    endpoints?: boolean
    config?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SourceOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "nameEn" | "type" | "country" | "region" | "level" | "enabled" | "endpoints" | "config" | "createdAt" | "updatedAt", ExtArgs["result"]["source"]>

  export type $SourcePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Source"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string
      nameEn: string
      type: string
      country: string
      region: string
      level: string
      enabled: number
      endpoints: string
      config: string
      createdAt: string
      updatedAt: string
    }, ExtArgs["result"]["source"]>
    composites: {}
  }

  type SourceGetPayload<S extends boolean | null | undefined | SourceDefaultArgs> = $Result.GetResult<Prisma.$SourcePayload, S>

  type SourceCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SourceFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SourceCountAggregateInputType | true
    }

  export interface SourceDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Source'], meta: { name: 'Source' } }
    /**
     * Find zero or one Source that matches the filter.
     * @param {SourceFindUniqueArgs} args - Arguments to find a Source
     * @example
     * // Get one Source
     * const source = await prisma.source.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SourceFindUniqueArgs>(args: SelectSubset<T, SourceFindUniqueArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Source that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SourceFindUniqueOrThrowArgs} args - Arguments to find a Source
     * @example
     * // Get one Source
     * const source = await prisma.source.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SourceFindUniqueOrThrowArgs>(args: SelectSubset<T, SourceFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Source that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceFindFirstArgs} args - Arguments to find a Source
     * @example
     * // Get one Source
     * const source = await prisma.source.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SourceFindFirstArgs>(args?: SelectSubset<T, SourceFindFirstArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Source that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceFindFirstOrThrowArgs} args - Arguments to find a Source
     * @example
     * // Get one Source
     * const source = await prisma.source.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SourceFindFirstOrThrowArgs>(args?: SelectSubset<T, SourceFindFirstOrThrowArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Sources that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Sources
     * const sources = await prisma.source.findMany()
     * 
     * // Get first 10 Sources
     * const sources = await prisma.source.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const sourceWithIdOnly = await prisma.source.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SourceFindManyArgs>(args?: SelectSubset<T, SourceFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Source.
     * @param {SourceCreateArgs} args - Arguments to create a Source.
     * @example
     * // Create one Source
     * const Source = await prisma.source.create({
     *   data: {
     *     // ... data to create a Source
     *   }
     * })
     * 
     */
    create<T extends SourceCreateArgs>(args: SelectSubset<T, SourceCreateArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Sources.
     * @param {SourceCreateManyArgs} args - Arguments to create many Sources.
     * @example
     * // Create many Sources
     * const source = await prisma.source.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SourceCreateManyArgs>(args?: SelectSubset<T, SourceCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Sources and returns the data saved in the database.
     * @param {SourceCreateManyAndReturnArgs} args - Arguments to create many Sources.
     * @example
     * // Create many Sources
     * const source = await prisma.source.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Sources and only return the `id`
     * const sourceWithIdOnly = await prisma.source.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SourceCreateManyAndReturnArgs>(args?: SelectSubset<T, SourceCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Source.
     * @param {SourceDeleteArgs} args - Arguments to delete one Source.
     * @example
     * // Delete one Source
     * const Source = await prisma.source.delete({
     *   where: {
     *     // ... filter to delete one Source
     *   }
     * })
     * 
     */
    delete<T extends SourceDeleteArgs>(args: SelectSubset<T, SourceDeleteArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Source.
     * @param {SourceUpdateArgs} args - Arguments to update one Source.
     * @example
     * // Update one Source
     * const source = await prisma.source.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SourceUpdateArgs>(args: SelectSubset<T, SourceUpdateArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Sources.
     * @param {SourceDeleteManyArgs} args - Arguments to filter Sources to delete.
     * @example
     * // Delete a few Sources
     * const { count } = await prisma.source.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SourceDeleteManyArgs>(args?: SelectSubset<T, SourceDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sources.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Sources
     * const source = await prisma.source.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SourceUpdateManyArgs>(args: SelectSubset<T, SourceUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Sources and returns the data updated in the database.
     * @param {SourceUpdateManyAndReturnArgs} args - Arguments to update many Sources.
     * @example
     * // Update many Sources
     * const source = await prisma.source.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Sources and only return the `id`
     * const sourceWithIdOnly = await prisma.source.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SourceUpdateManyAndReturnArgs>(args: SelectSubset<T, SourceUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Source.
     * @param {SourceUpsertArgs} args - Arguments to update or create a Source.
     * @example
     * // Update or create a Source
     * const source = await prisma.source.upsert({
     *   create: {
     *     // ... data to create a Source
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Source we want to update
     *   }
     * })
     */
    upsert<T extends SourceUpsertArgs>(args: SelectSubset<T, SourceUpsertArgs<ExtArgs>>): Prisma__SourceClient<$Result.GetResult<Prisma.$SourcePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Sources.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceCountArgs} args - Arguments to filter Sources to count.
     * @example
     * // Count the number of Sources
     * const count = await prisma.source.count({
     *   where: {
     *     // ... the filter for the Sources we want to count
     *   }
     * })
    **/
    count<T extends SourceCountArgs>(
      args?: Subset<T, SourceCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SourceCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Source.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SourceAggregateArgs>(args: Subset<T, SourceAggregateArgs>): Prisma.PrismaPromise<GetSourceAggregateType<T>>

    /**
     * Group by Source.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SourceGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SourceGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SourceGroupByArgs['orderBy'] }
        : { orderBy?: SourceGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SourceGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSourceGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Source model
   */
  readonly fields: SourceFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Source.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SourceClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Source model
   */
  interface SourceFieldRefs {
    readonly id: FieldRef<"Source", 'String'>
    readonly name: FieldRef<"Source", 'String'>
    readonly nameEn: FieldRef<"Source", 'String'>
    readonly type: FieldRef<"Source", 'String'>
    readonly country: FieldRef<"Source", 'String'>
    readonly region: FieldRef<"Source", 'String'>
    readonly level: FieldRef<"Source", 'String'>
    readonly enabled: FieldRef<"Source", 'Int'>
    readonly endpoints: FieldRef<"Source", 'String'>
    readonly config: FieldRef<"Source", 'String'>
    readonly createdAt: FieldRef<"Source", 'String'>
    readonly updatedAt: FieldRef<"Source", 'String'>
  }
    

  // Custom InputTypes
  /**
   * Source findUnique
   */
  export type SourceFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter, which Source to fetch.
     */
    where: SourceWhereUniqueInput
  }

  /**
   * Source findUniqueOrThrow
   */
  export type SourceFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter, which Source to fetch.
     */
    where: SourceWhereUniqueInput
  }

  /**
   * Source findFirst
   */
  export type SourceFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter, which Source to fetch.
     */
    where?: SourceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sources to fetch.
     */
    orderBy?: SourceOrderByWithRelationInput | SourceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sources.
     */
    cursor?: SourceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sources from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sources.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sources.
     */
    distinct?: SourceScalarFieldEnum | SourceScalarFieldEnum[]
  }

  /**
   * Source findFirstOrThrow
   */
  export type SourceFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter, which Source to fetch.
     */
    where?: SourceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sources to fetch.
     */
    orderBy?: SourceOrderByWithRelationInput | SourceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Sources.
     */
    cursor?: SourceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sources from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sources.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sources.
     */
    distinct?: SourceScalarFieldEnum | SourceScalarFieldEnum[]
  }

  /**
   * Source findMany
   */
  export type SourceFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter, which Sources to fetch.
     */
    where?: SourceWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Sources to fetch.
     */
    orderBy?: SourceOrderByWithRelationInput | SourceOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Sources.
     */
    cursor?: SourceWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Sources from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Sources.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Sources.
     */
    distinct?: SourceScalarFieldEnum | SourceScalarFieldEnum[]
  }

  /**
   * Source create
   */
  export type SourceCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * The data needed to create a Source.
     */
    data: XOR<SourceCreateInput, SourceUncheckedCreateInput>
  }

  /**
   * Source createMany
   */
  export type SourceCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Sources.
     */
    data: SourceCreateManyInput | SourceCreateManyInput[]
  }

  /**
   * Source createManyAndReturn
   */
  export type SourceCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * The data used to create many Sources.
     */
    data: SourceCreateManyInput | SourceCreateManyInput[]
  }

  /**
   * Source update
   */
  export type SourceUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * The data needed to update a Source.
     */
    data: XOR<SourceUpdateInput, SourceUncheckedUpdateInput>
    /**
     * Choose, which Source to update.
     */
    where: SourceWhereUniqueInput
  }

  /**
   * Source updateMany
   */
  export type SourceUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Sources.
     */
    data: XOR<SourceUpdateManyMutationInput, SourceUncheckedUpdateManyInput>
    /**
     * Filter which Sources to update
     */
    where?: SourceWhereInput
    /**
     * Limit how many Sources to update.
     */
    limit?: number
  }

  /**
   * Source updateManyAndReturn
   */
  export type SourceUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * The data used to update Sources.
     */
    data: XOR<SourceUpdateManyMutationInput, SourceUncheckedUpdateManyInput>
    /**
     * Filter which Sources to update
     */
    where?: SourceWhereInput
    /**
     * Limit how many Sources to update.
     */
    limit?: number
  }

  /**
   * Source upsert
   */
  export type SourceUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * The filter to search for the Source to update in case it exists.
     */
    where: SourceWhereUniqueInput
    /**
     * In case the Source found by the `where` argument doesn't exist, create a new Source with this data.
     */
    create: XOR<SourceCreateInput, SourceUncheckedCreateInput>
    /**
     * In case the Source was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SourceUpdateInput, SourceUncheckedUpdateInput>
  }

  /**
   * Source delete
   */
  export type SourceDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
    /**
     * Filter which Source to delete.
     */
    where: SourceWhereUniqueInput
  }

  /**
   * Source deleteMany
   */
  export type SourceDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Sources to delete
     */
    where?: SourceWhereInput
    /**
     * Limit how many Sources to delete.
     */
    limit?: number
  }

  /**
   * Source without action
   */
  export type SourceDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Source
     */
    select?: SourceSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Source
     */
    omit?: SourceOmit<ExtArgs> | null
  }


  /**
   * Model CrawlLog
   */

  export type AggregateCrawlLog = {
    _count: CrawlLogCountAggregateOutputType | null
    _avg: CrawlLogAvgAggregateOutputType | null
    _sum: CrawlLogSumAggregateOutputType | null
    _min: CrawlLogMinAggregateOutputType | null
    _max: CrawlLogMaxAggregateOutputType | null
  }

  export type CrawlLogAvgAggregateOutputType = {
    id: number | null
    itemsTotal: number | null
    itemsNew: number | null
    itemsDup: number | null
    durationMs: number | null
  }

  export type CrawlLogSumAggregateOutputType = {
    id: number | null
    itemsTotal: number | null
    itemsNew: number | null
    itemsDup: number | null
    durationMs: number | null
  }

  export type CrawlLogMinAggregateOutputType = {
    id: number | null
    sourceId: string | null
    startedAt: string | null
    finishedAt: string | null
    status: string | null
    itemsTotal: number | null
    itemsNew: number | null
    itemsDup: number | null
    errorMsg: string | null
    durationMs: number | null
    createdAt: string | null
  }

  export type CrawlLogMaxAggregateOutputType = {
    id: number | null
    sourceId: string | null
    startedAt: string | null
    finishedAt: string | null
    status: string | null
    itemsTotal: number | null
    itemsNew: number | null
    itemsDup: number | null
    errorMsg: string | null
    durationMs: number | null
    createdAt: string | null
  }

  export type CrawlLogCountAggregateOutputType = {
    id: number
    sourceId: number
    startedAt: number
    finishedAt: number
    status: number
    itemsTotal: number
    itemsNew: number
    itemsDup: number
    errorMsg: number
    durationMs: number
    createdAt: number
    _all: number
  }


  export type CrawlLogAvgAggregateInputType = {
    id?: true
    itemsTotal?: true
    itemsNew?: true
    itemsDup?: true
    durationMs?: true
  }

  export type CrawlLogSumAggregateInputType = {
    id?: true
    itemsTotal?: true
    itemsNew?: true
    itemsDup?: true
    durationMs?: true
  }

  export type CrawlLogMinAggregateInputType = {
    id?: true
    sourceId?: true
    startedAt?: true
    finishedAt?: true
    status?: true
    itemsTotal?: true
    itemsNew?: true
    itemsDup?: true
    errorMsg?: true
    durationMs?: true
    createdAt?: true
  }

  export type CrawlLogMaxAggregateInputType = {
    id?: true
    sourceId?: true
    startedAt?: true
    finishedAt?: true
    status?: true
    itemsTotal?: true
    itemsNew?: true
    itemsDup?: true
    errorMsg?: true
    durationMs?: true
    createdAt?: true
  }

  export type CrawlLogCountAggregateInputType = {
    id?: true
    sourceId?: true
    startedAt?: true
    finishedAt?: true
    status?: true
    itemsTotal?: true
    itemsNew?: true
    itemsDup?: true
    errorMsg?: true
    durationMs?: true
    createdAt?: true
    _all?: true
  }

  export type CrawlLogAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CrawlLog to aggregate.
     */
    where?: CrawlLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CrawlLogs to fetch.
     */
    orderBy?: CrawlLogOrderByWithRelationInput | CrawlLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CrawlLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CrawlLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CrawlLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CrawlLogs
    **/
    _count?: true | CrawlLogCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CrawlLogAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CrawlLogSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CrawlLogMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CrawlLogMaxAggregateInputType
  }

  export type GetCrawlLogAggregateType<T extends CrawlLogAggregateArgs> = {
        [P in keyof T & keyof AggregateCrawlLog]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCrawlLog[P]>
      : GetScalarType<T[P], AggregateCrawlLog[P]>
  }




  export type CrawlLogGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CrawlLogWhereInput
    orderBy?: CrawlLogOrderByWithAggregationInput | CrawlLogOrderByWithAggregationInput[]
    by: CrawlLogScalarFieldEnum[] | CrawlLogScalarFieldEnum
    having?: CrawlLogScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CrawlLogCountAggregateInputType | true
    _avg?: CrawlLogAvgAggregateInputType
    _sum?: CrawlLogSumAggregateInputType
    _min?: CrawlLogMinAggregateInputType
    _max?: CrawlLogMaxAggregateInputType
  }

  export type CrawlLogGroupByOutputType = {
    id: number
    sourceId: string
    startedAt: string
    finishedAt: string | null
    status: string
    itemsTotal: number
    itemsNew: number
    itemsDup: number
    errorMsg: string | null
    durationMs: number | null
    createdAt: string
    _count: CrawlLogCountAggregateOutputType | null
    _avg: CrawlLogAvgAggregateOutputType | null
    _sum: CrawlLogSumAggregateOutputType | null
    _min: CrawlLogMinAggregateOutputType | null
    _max: CrawlLogMaxAggregateOutputType | null
  }

  type GetCrawlLogGroupByPayload<T extends CrawlLogGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CrawlLogGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CrawlLogGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CrawlLogGroupByOutputType[P]>
            : GetScalarType<T[P], CrawlLogGroupByOutputType[P]>
        }
      >
    >


  export type CrawlLogSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sourceId?: boolean
    startedAt?: boolean
    finishedAt?: boolean
    status?: boolean
    itemsTotal?: boolean
    itemsNew?: boolean
    itemsDup?: boolean
    errorMsg?: boolean
    durationMs?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["crawlLog"]>

  export type CrawlLogSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sourceId?: boolean
    startedAt?: boolean
    finishedAt?: boolean
    status?: boolean
    itemsTotal?: boolean
    itemsNew?: boolean
    itemsDup?: boolean
    errorMsg?: boolean
    durationMs?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["crawlLog"]>

  export type CrawlLogSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    sourceId?: boolean
    startedAt?: boolean
    finishedAt?: boolean
    status?: boolean
    itemsTotal?: boolean
    itemsNew?: boolean
    itemsDup?: boolean
    errorMsg?: boolean
    durationMs?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["crawlLog"]>

  export type CrawlLogSelectScalar = {
    id?: boolean
    sourceId?: boolean
    startedAt?: boolean
    finishedAt?: boolean
    status?: boolean
    itemsTotal?: boolean
    itemsNew?: boolean
    itemsDup?: boolean
    errorMsg?: boolean
    durationMs?: boolean
    createdAt?: boolean
  }

  export type CrawlLogOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "sourceId" | "startedAt" | "finishedAt" | "status" | "itemsTotal" | "itemsNew" | "itemsDup" | "errorMsg" | "durationMs" | "createdAt", ExtArgs["result"]["crawlLog"]>

  export type $CrawlLogPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CrawlLog"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      sourceId: string
      startedAt: string
      finishedAt: string | null
      status: string
      itemsTotal: number
      itemsNew: number
      itemsDup: number
      errorMsg: string | null
      durationMs: number | null
      createdAt: string
    }, ExtArgs["result"]["crawlLog"]>
    composites: {}
  }

  type CrawlLogGetPayload<S extends boolean | null | undefined | CrawlLogDefaultArgs> = $Result.GetResult<Prisma.$CrawlLogPayload, S>

  type CrawlLogCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CrawlLogFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CrawlLogCountAggregateInputType | true
    }

  export interface CrawlLogDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CrawlLog'], meta: { name: 'CrawlLog' } }
    /**
     * Find zero or one CrawlLog that matches the filter.
     * @param {CrawlLogFindUniqueArgs} args - Arguments to find a CrawlLog
     * @example
     * // Get one CrawlLog
     * const crawlLog = await prisma.crawlLog.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CrawlLogFindUniqueArgs>(args: SelectSubset<T, CrawlLogFindUniqueArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CrawlLog that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CrawlLogFindUniqueOrThrowArgs} args - Arguments to find a CrawlLog
     * @example
     * // Get one CrawlLog
     * const crawlLog = await prisma.crawlLog.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CrawlLogFindUniqueOrThrowArgs>(args: SelectSubset<T, CrawlLogFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CrawlLog that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogFindFirstArgs} args - Arguments to find a CrawlLog
     * @example
     * // Get one CrawlLog
     * const crawlLog = await prisma.crawlLog.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CrawlLogFindFirstArgs>(args?: SelectSubset<T, CrawlLogFindFirstArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CrawlLog that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogFindFirstOrThrowArgs} args - Arguments to find a CrawlLog
     * @example
     * // Get one CrawlLog
     * const crawlLog = await prisma.crawlLog.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CrawlLogFindFirstOrThrowArgs>(args?: SelectSubset<T, CrawlLogFindFirstOrThrowArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CrawlLogs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CrawlLogs
     * const crawlLogs = await prisma.crawlLog.findMany()
     * 
     * // Get first 10 CrawlLogs
     * const crawlLogs = await prisma.crawlLog.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const crawlLogWithIdOnly = await prisma.crawlLog.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CrawlLogFindManyArgs>(args?: SelectSubset<T, CrawlLogFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CrawlLog.
     * @param {CrawlLogCreateArgs} args - Arguments to create a CrawlLog.
     * @example
     * // Create one CrawlLog
     * const CrawlLog = await prisma.crawlLog.create({
     *   data: {
     *     // ... data to create a CrawlLog
     *   }
     * })
     * 
     */
    create<T extends CrawlLogCreateArgs>(args: SelectSubset<T, CrawlLogCreateArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CrawlLogs.
     * @param {CrawlLogCreateManyArgs} args - Arguments to create many CrawlLogs.
     * @example
     * // Create many CrawlLogs
     * const crawlLog = await prisma.crawlLog.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CrawlLogCreateManyArgs>(args?: SelectSubset<T, CrawlLogCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CrawlLogs and returns the data saved in the database.
     * @param {CrawlLogCreateManyAndReturnArgs} args - Arguments to create many CrawlLogs.
     * @example
     * // Create many CrawlLogs
     * const crawlLog = await prisma.crawlLog.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CrawlLogs and only return the `id`
     * const crawlLogWithIdOnly = await prisma.crawlLog.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CrawlLogCreateManyAndReturnArgs>(args?: SelectSubset<T, CrawlLogCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CrawlLog.
     * @param {CrawlLogDeleteArgs} args - Arguments to delete one CrawlLog.
     * @example
     * // Delete one CrawlLog
     * const CrawlLog = await prisma.crawlLog.delete({
     *   where: {
     *     // ... filter to delete one CrawlLog
     *   }
     * })
     * 
     */
    delete<T extends CrawlLogDeleteArgs>(args: SelectSubset<T, CrawlLogDeleteArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CrawlLog.
     * @param {CrawlLogUpdateArgs} args - Arguments to update one CrawlLog.
     * @example
     * // Update one CrawlLog
     * const crawlLog = await prisma.crawlLog.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CrawlLogUpdateArgs>(args: SelectSubset<T, CrawlLogUpdateArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CrawlLogs.
     * @param {CrawlLogDeleteManyArgs} args - Arguments to filter CrawlLogs to delete.
     * @example
     * // Delete a few CrawlLogs
     * const { count } = await prisma.crawlLog.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CrawlLogDeleteManyArgs>(args?: SelectSubset<T, CrawlLogDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CrawlLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CrawlLogs
     * const crawlLog = await prisma.crawlLog.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CrawlLogUpdateManyArgs>(args: SelectSubset<T, CrawlLogUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CrawlLogs and returns the data updated in the database.
     * @param {CrawlLogUpdateManyAndReturnArgs} args - Arguments to update many CrawlLogs.
     * @example
     * // Update many CrawlLogs
     * const crawlLog = await prisma.crawlLog.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CrawlLogs and only return the `id`
     * const crawlLogWithIdOnly = await prisma.crawlLog.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CrawlLogUpdateManyAndReturnArgs>(args: SelectSubset<T, CrawlLogUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CrawlLog.
     * @param {CrawlLogUpsertArgs} args - Arguments to update or create a CrawlLog.
     * @example
     * // Update or create a CrawlLog
     * const crawlLog = await prisma.crawlLog.upsert({
     *   create: {
     *     // ... data to create a CrawlLog
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CrawlLog we want to update
     *   }
     * })
     */
    upsert<T extends CrawlLogUpsertArgs>(args: SelectSubset<T, CrawlLogUpsertArgs<ExtArgs>>): Prisma__CrawlLogClient<$Result.GetResult<Prisma.$CrawlLogPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CrawlLogs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogCountArgs} args - Arguments to filter CrawlLogs to count.
     * @example
     * // Count the number of CrawlLogs
     * const count = await prisma.crawlLog.count({
     *   where: {
     *     // ... the filter for the CrawlLogs we want to count
     *   }
     * })
    **/
    count<T extends CrawlLogCountArgs>(
      args?: Subset<T, CrawlLogCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CrawlLogCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CrawlLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CrawlLogAggregateArgs>(args: Subset<T, CrawlLogAggregateArgs>): Prisma.PrismaPromise<GetCrawlLogAggregateType<T>>

    /**
     * Group by CrawlLog.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CrawlLogGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CrawlLogGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CrawlLogGroupByArgs['orderBy'] }
        : { orderBy?: CrawlLogGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CrawlLogGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCrawlLogGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CrawlLog model
   */
  readonly fields: CrawlLogFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CrawlLog.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CrawlLogClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CrawlLog model
   */
  interface CrawlLogFieldRefs {
    readonly id: FieldRef<"CrawlLog", 'Int'>
    readonly sourceId: FieldRef<"CrawlLog", 'String'>
    readonly startedAt: FieldRef<"CrawlLog", 'String'>
    readonly finishedAt: FieldRef<"CrawlLog", 'String'>
    readonly status: FieldRef<"CrawlLog", 'String'>
    readonly itemsTotal: FieldRef<"CrawlLog", 'Int'>
    readonly itemsNew: FieldRef<"CrawlLog", 'Int'>
    readonly itemsDup: FieldRef<"CrawlLog", 'Int'>
    readonly errorMsg: FieldRef<"CrawlLog", 'String'>
    readonly durationMs: FieldRef<"CrawlLog", 'Int'>
    readonly createdAt: FieldRef<"CrawlLog", 'String'>
  }
    

  // Custom InputTypes
  /**
   * CrawlLog findUnique
   */
  export type CrawlLogFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter, which CrawlLog to fetch.
     */
    where: CrawlLogWhereUniqueInput
  }

  /**
   * CrawlLog findUniqueOrThrow
   */
  export type CrawlLogFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter, which CrawlLog to fetch.
     */
    where: CrawlLogWhereUniqueInput
  }

  /**
   * CrawlLog findFirst
   */
  export type CrawlLogFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter, which CrawlLog to fetch.
     */
    where?: CrawlLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CrawlLogs to fetch.
     */
    orderBy?: CrawlLogOrderByWithRelationInput | CrawlLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CrawlLogs.
     */
    cursor?: CrawlLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CrawlLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CrawlLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CrawlLogs.
     */
    distinct?: CrawlLogScalarFieldEnum | CrawlLogScalarFieldEnum[]
  }

  /**
   * CrawlLog findFirstOrThrow
   */
  export type CrawlLogFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter, which CrawlLog to fetch.
     */
    where?: CrawlLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CrawlLogs to fetch.
     */
    orderBy?: CrawlLogOrderByWithRelationInput | CrawlLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CrawlLogs.
     */
    cursor?: CrawlLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CrawlLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CrawlLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CrawlLogs.
     */
    distinct?: CrawlLogScalarFieldEnum | CrawlLogScalarFieldEnum[]
  }

  /**
   * CrawlLog findMany
   */
  export type CrawlLogFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter, which CrawlLogs to fetch.
     */
    where?: CrawlLogWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CrawlLogs to fetch.
     */
    orderBy?: CrawlLogOrderByWithRelationInput | CrawlLogOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CrawlLogs.
     */
    cursor?: CrawlLogWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CrawlLogs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CrawlLogs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CrawlLogs.
     */
    distinct?: CrawlLogScalarFieldEnum | CrawlLogScalarFieldEnum[]
  }

  /**
   * CrawlLog create
   */
  export type CrawlLogCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * The data needed to create a CrawlLog.
     */
    data: XOR<CrawlLogCreateInput, CrawlLogUncheckedCreateInput>
  }

  /**
   * CrawlLog createMany
   */
  export type CrawlLogCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CrawlLogs.
     */
    data: CrawlLogCreateManyInput | CrawlLogCreateManyInput[]
  }

  /**
   * CrawlLog createManyAndReturn
   */
  export type CrawlLogCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * The data used to create many CrawlLogs.
     */
    data: CrawlLogCreateManyInput | CrawlLogCreateManyInput[]
  }

  /**
   * CrawlLog update
   */
  export type CrawlLogUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * The data needed to update a CrawlLog.
     */
    data: XOR<CrawlLogUpdateInput, CrawlLogUncheckedUpdateInput>
    /**
     * Choose, which CrawlLog to update.
     */
    where: CrawlLogWhereUniqueInput
  }

  /**
   * CrawlLog updateMany
   */
  export type CrawlLogUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CrawlLogs.
     */
    data: XOR<CrawlLogUpdateManyMutationInput, CrawlLogUncheckedUpdateManyInput>
    /**
     * Filter which CrawlLogs to update
     */
    where?: CrawlLogWhereInput
    /**
     * Limit how many CrawlLogs to update.
     */
    limit?: number
  }

  /**
   * CrawlLog updateManyAndReturn
   */
  export type CrawlLogUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * The data used to update CrawlLogs.
     */
    data: XOR<CrawlLogUpdateManyMutationInput, CrawlLogUncheckedUpdateManyInput>
    /**
     * Filter which CrawlLogs to update
     */
    where?: CrawlLogWhereInput
    /**
     * Limit how many CrawlLogs to update.
     */
    limit?: number
  }

  /**
   * CrawlLog upsert
   */
  export type CrawlLogUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * The filter to search for the CrawlLog to update in case it exists.
     */
    where: CrawlLogWhereUniqueInput
    /**
     * In case the CrawlLog found by the `where` argument doesn't exist, create a new CrawlLog with this data.
     */
    create: XOR<CrawlLogCreateInput, CrawlLogUncheckedCreateInput>
    /**
     * In case the CrawlLog was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CrawlLogUpdateInput, CrawlLogUncheckedUpdateInput>
  }

  /**
   * CrawlLog delete
   */
  export type CrawlLogDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
    /**
     * Filter which CrawlLog to delete.
     */
    where: CrawlLogWhereUniqueInput
  }

  /**
   * CrawlLog deleteMany
   */
  export type CrawlLogDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CrawlLogs to delete
     */
    where?: CrawlLogWhereInput
    /**
     * Limit how many CrawlLogs to delete.
     */
    limit?: number
  }

  /**
   * CrawlLog without action
   */
  export type CrawlLogDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CrawlLog
     */
    select?: CrawlLogSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CrawlLog
     */
    omit?: CrawlLogOmit<ExtArgs> | null
  }


  /**
   * Model AiAnalysis
   */

  export type AggregateAiAnalysis = {
    _count: AiAnalysisCountAggregateOutputType | null
    _avg: AiAnalysisAvgAggregateOutputType | null
    _sum: AiAnalysisSumAggregateOutputType | null
    _min: AiAnalysisMinAggregateOutputType | null
    _max: AiAnalysisMaxAggregateOutputType | null
  }

  export type AiAnalysisAvgAggregateOutputType = {
    id: number | null
    inputTokens: number | null
    outputTokens: number | null
    cost: number | null
    durationMs: number | null
  }

  export type AiAnalysisSumAggregateOutputType = {
    id: number | null
    inputTokens: number | null
    outputTokens: number | null
    cost: number | null
    durationMs: number | null
  }

  export type AiAnalysisMinAggregateOutputType = {
    id: number | null
    eventId: string | null
    model: string | null
    task: string | null
    inputTokens: number | null
    outputTokens: number | null
    cost: number | null
    durationMs: number | null
    status: string | null
    errorMsg: string | null
    createdAt: string | null
  }

  export type AiAnalysisMaxAggregateOutputType = {
    id: number | null
    eventId: string | null
    model: string | null
    task: string | null
    inputTokens: number | null
    outputTokens: number | null
    cost: number | null
    durationMs: number | null
    status: string | null
    errorMsg: string | null
    createdAt: string | null
  }

  export type AiAnalysisCountAggregateOutputType = {
    id: number
    eventId: number
    model: number
    task: number
    inputTokens: number
    outputTokens: number
    cost: number
    durationMs: number
    status: number
    errorMsg: number
    createdAt: number
    _all: number
  }


  export type AiAnalysisAvgAggregateInputType = {
    id?: true
    inputTokens?: true
    outputTokens?: true
    cost?: true
    durationMs?: true
  }

  export type AiAnalysisSumAggregateInputType = {
    id?: true
    inputTokens?: true
    outputTokens?: true
    cost?: true
    durationMs?: true
  }

  export type AiAnalysisMinAggregateInputType = {
    id?: true
    eventId?: true
    model?: true
    task?: true
    inputTokens?: true
    outputTokens?: true
    cost?: true
    durationMs?: true
    status?: true
    errorMsg?: true
    createdAt?: true
  }

  export type AiAnalysisMaxAggregateInputType = {
    id?: true
    eventId?: true
    model?: true
    task?: true
    inputTokens?: true
    outputTokens?: true
    cost?: true
    durationMs?: true
    status?: true
    errorMsg?: true
    createdAt?: true
  }

  export type AiAnalysisCountAggregateInputType = {
    id?: true
    eventId?: true
    model?: true
    task?: true
    inputTokens?: true
    outputTokens?: true
    cost?: true
    durationMs?: true
    status?: true
    errorMsg?: true
    createdAt?: true
    _all?: true
  }

  export type AiAnalysisAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AiAnalysis to aggregate.
     */
    where?: AiAnalysisWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AiAnalyses to fetch.
     */
    orderBy?: AiAnalysisOrderByWithRelationInput | AiAnalysisOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: AiAnalysisWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AiAnalyses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AiAnalyses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned AiAnalyses
    **/
    _count?: true | AiAnalysisCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: AiAnalysisAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: AiAnalysisSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: AiAnalysisMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: AiAnalysisMaxAggregateInputType
  }

  export type GetAiAnalysisAggregateType<T extends AiAnalysisAggregateArgs> = {
        [P in keyof T & keyof AggregateAiAnalysis]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateAiAnalysis[P]>
      : GetScalarType<T[P], AggregateAiAnalysis[P]>
  }




  export type AiAnalysisGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: AiAnalysisWhereInput
    orderBy?: AiAnalysisOrderByWithAggregationInput | AiAnalysisOrderByWithAggregationInput[]
    by: AiAnalysisScalarFieldEnum[] | AiAnalysisScalarFieldEnum
    having?: AiAnalysisScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: AiAnalysisCountAggregateInputType | true
    _avg?: AiAnalysisAvgAggregateInputType
    _sum?: AiAnalysisSumAggregateInputType
    _min?: AiAnalysisMinAggregateInputType
    _max?: AiAnalysisMaxAggregateInputType
  }

  export type AiAnalysisGroupByOutputType = {
    id: number
    eventId: string
    model: string
    task: string
    inputTokens: number
    outputTokens: number
    cost: number
    durationMs: number | null
    status: string
    errorMsg: string | null
    createdAt: string
    _count: AiAnalysisCountAggregateOutputType | null
    _avg: AiAnalysisAvgAggregateOutputType | null
    _sum: AiAnalysisSumAggregateOutputType | null
    _min: AiAnalysisMinAggregateOutputType | null
    _max: AiAnalysisMaxAggregateOutputType | null
  }

  type GetAiAnalysisGroupByPayload<T extends AiAnalysisGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<AiAnalysisGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof AiAnalysisGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], AiAnalysisGroupByOutputType[P]>
            : GetScalarType<T[P], AiAnalysisGroupByOutputType[P]>
        }
      >
    >


  export type AiAnalysisSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    eventId?: boolean
    model?: boolean
    task?: boolean
    inputTokens?: boolean
    outputTokens?: boolean
    cost?: boolean
    durationMs?: boolean
    status?: boolean
    errorMsg?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["aiAnalysis"]>

  export type AiAnalysisSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    eventId?: boolean
    model?: boolean
    task?: boolean
    inputTokens?: boolean
    outputTokens?: boolean
    cost?: boolean
    durationMs?: boolean
    status?: boolean
    errorMsg?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["aiAnalysis"]>

  export type AiAnalysisSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    eventId?: boolean
    model?: boolean
    task?: boolean
    inputTokens?: boolean
    outputTokens?: boolean
    cost?: boolean
    durationMs?: boolean
    status?: boolean
    errorMsg?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["aiAnalysis"]>

  export type AiAnalysisSelectScalar = {
    id?: boolean
    eventId?: boolean
    model?: boolean
    task?: boolean
    inputTokens?: boolean
    outputTokens?: boolean
    cost?: boolean
    durationMs?: boolean
    status?: boolean
    errorMsg?: boolean
    createdAt?: boolean
  }

  export type AiAnalysisOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "eventId" | "model" | "task" | "inputTokens" | "outputTokens" | "cost" | "durationMs" | "status" | "errorMsg" | "createdAt", ExtArgs["result"]["aiAnalysis"]>

  export type $AiAnalysisPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "AiAnalysis"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: number
      eventId: string
      model: string
      task: string
      inputTokens: number
      outputTokens: number
      cost: number
      durationMs: number | null
      status: string
      errorMsg: string | null
      createdAt: string
    }, ExtArgs["result"]["aiAnalysis"]>
    composites: {}
  }

  type AiAnalysisGetPayload<S extends boolean | null | undefined | AiAnalysisDefaultArgs> = $Result.GetResult<Prisma.$AiAnalysisPayload, S>

  type AiAnalysisCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<AiAnalysisFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: AiAnalysisCountAggregateInputType | true
    }

  export interface AiAnalysisDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['AiAnalysis'], meta: { name: 'AiAnalysis' } }
    /**
     * Find zero or one AiAnalysis that matches the filter.
     * @param {AiAnalysisFindUniqueArgs} args - Arguments to find a AiAnalysis
     * @example
     * // Get one AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends AiAnalysisFindUniqueArgs>(args: SelectSubset<T, AiAnalysisFindUniqueArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one AiAnalysis that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {AiAnalysisFindUniqueOrThrowArgs} args - Arguments to find a AiAnalysis
     * @example
     * // Get one AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends AiAnalysisFindUniqueOrThrowArgs>(args: SelectSubset<T, AiAnalysisFindUniqueOrThrowArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AiAnalysis that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisFindFirstArgs} args - Arguments to find a AiAnalysis
     * @example
     * // Get one AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends AiAnalysisFindFirstArgs>(args?: SelectSubset<T, AiAnalysisFindFirstArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first AiAnalysis that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisFindFirstOrThrowArgs} args - Arguments to find a AiAnalysis
     * @example
     * // Get one AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends AiAnalysisFindFirstOrThrowArgs>(args?: SelectSubset<T, AiAnalysisFindFirstOrThrowArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more AiAnalyses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all AiAnalyses
     * const aiAnalyses = await prisma.aiAnalysis.findMany()
     * 
     * // Get first 10 AiAnalyses
     * const aiAnalyses = await prisma.aiAnalysis.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const aiAnalysisWithIdOnly = await prisma.aiAnalysis.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends AiAnalysisFindManyArgs>(args?: SelectSubset<T, AiAnalysisFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a AiAnalysis.
     * @param {AiAnalysisCreateArgs} args - Arguments to create a AiAnalysis.
     * @example
     * // Create one AiAnalysis
     * const AiAnalysis = await prisma.aiAnalysis.create({
     *   data: {
     *     // ... data to create a AiAnalysis
     *   }
     * })
     * 
     */
    create<T extends AiAnalysisCreateArgs>(args: SelectSubset<T, AiAnalysisCreateArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many AiAnalyses.
     * @param {AiAnalysisCreateManyArgs} args - Arguments to create many AiAnalyses.
     * @example
     * // Create many AiAnalyses
     * const aiAnalysis = await prisma.aiAnalysis.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends AiAnalysisCreateManyArgs>(args?: SelectSubset<T, AiAnalysisCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many AiAnalyses and returns the data saved in the database.
     * @param {AiAnalysisCreateManyAndReturnArgs} args - Arguments to create many AiAnalyses.
     * @example
     * // Create many AiAnalyses
     * const aiAnalysis = await prisma.aiAnalysis.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many AiAnalyses and only return the `id`
     * const aiAnalysisWithIdOnly = await prisma.aiAnalysis.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends AiAnalysisCreateManyAndReturnArgs>(args?: SelectSubset<T, AiAnalysisCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a AiAnalysis.
     * @param {AiAnalysisDeleteArgs} args - Arguments to delete one AiAnalysis.
     * @example
     * // Delete one AiAnalysis
     * const AiAnalysis = await prisma.aiAnalysis.delete({
     *   where: {
     *     // ... filter to delete one AiAnalysis
     *   }
     * })
     * 
     */
    delete<T extends AiAnalysisDeleteArgs>(args: SelectSubset<T, AiAnalysisDeleteArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one AiAnalysis.
     * @param {AiAnalysisUpdateArgs} args - Arguments to update one AiAnalysis.
     * @example
     * // Update one AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends AiAnalysisUpdateArgs>(args: SelectSubset<T, AiAnalysisUpdateArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more AiAnalyses.
     * @param {AiAnalysisDeleteManyArgs} args - Arguments to filter AiAnalyses to delete.
     * @example
     * // Delete a few AiAnalyses
     * const { count } = await prisma.aiAnalysis.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends AiAnalysisDeleteManyArgs>(args?: SelectSubset<T, AiAnalysisDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AiAnalyses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many AiAnalyses
     * const aiAnalysis = await prisma.aiAnalysis.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends AiAnalysisUpdateManyArgs>(args: SelectSubset<T, AiAnalysisUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more AiAnalyses and returns the data updated in the database.
     * @param {AiAnalysisUpdateManyAndReturnArgs} args - Arguments to update many AiAnalyses.
     * @example
     * // Update many AiAnalyses
     * const aiAnalysis = await prisma.aiAnalysis.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more AiAnalyses and only return the `id`
     * const aiAnalysisWithIdOnly = await prisma.aiAnalysis.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends AiAnalysisUpdateManyAndReturnArgs>(args: SelectSubset<T, AiAnalysisUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one AiAnalysis.
     * @param {AiAnalysisUpsertArgs} args - Arguments to update or create a AiAnalysis.
     * @example
     * // Update or create a AiAnalysis
     * const aiAnalysis = await prisma.aiAnalysis.upsert({
     *   create: {
     *     // ... data to create a AiAnalysis
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the AiAnalysis we want to update
     *   }
     * })
     */
    upsert<T extends AiAnalysisUpsertArgs>(args: SelectSubset<T, AiAnalysisUpsertArgs<ExtArgs>>): Prisma__AiAnalysisClient<$Result.GetResult<Prisma.$AiAnalysisPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of AiAnalyses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisCountArgs} args - Arguments to filter AiAnalyses to count.
     * @example
     * // Count the number of AiAnalyses
     * const count = await prisma.aiAnalysis.count({
     *   where: {
     *     // ... the filter for the AiAnalyses we want to count
     *   }
     * })
    **/
    count<T extends AiAnalysisCountArgs>(
      args?: Subset<T, AiAnalysisCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], AiAnalysisCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a AiAnalysis.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends AiAnalysisAggregateArgs>(args: Subset<T, AiAnalysisAggregateArgs>): Prisma.PrismaPromise<GetAiAnalysisAggregateType<T>>

    /**
     * Group by AiAnalysis.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {AiAnalysisGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends AiAnalysisGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: AiAnalysisGroupByArgs['orderBy'] }
        : { orderBy?: AiAnalysisGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, AiAnalysisGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetAiAnalysisGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the AiAnalysis model
   */
  readonly fields: AiAnalysisFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for AiAnalysis.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__AiAnalysisClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the AiAnalysis model
   */
  interface AiAnalysisFieldRefs {
    readonly id: FieldRef<"AiAnalysis", 'Int'>
    readonly eventId: FieldRef<"AiAnalysis", 'String'>
    readonly model: FieldRef<"AiAnalysis", 'String'>
    readonly task: FieldRef<"AiAnalysis", 'String'>
    readonly inputTokens: FieldRef<"AiAnalysis", 'Int'>
    readonly outputTokens: FieldRef<"AiAnalysis", 'Int'>
    readonly cost: FieldRef<"AiAnalysis", 'Float'>
    readonly durationMs: FieldRef<"AiAnalysis", 'Int'>
    readonly status: FieldRef<"AiAnalysis", 'String'>
    readonly errorMsg: FieldRef<"AiAnalysis", 'String'>
    readonly createdAt: FieldRef<"AiAnalysis", 'String'>
  }
    

  // Custom InputTypes
  /**
   * AiAnalysis findUnique
   */
  export type AiAnalysisFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter, which AiAnalysis to fetch.
     */
    where: AiAnalysisWhereUniqueInput
  }

  /**
   * AiAnalysis findUniqueOrThrow
   */
  export type AiAnalysisFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter, which AiAnalysis to fetch.
     */
    where: AiAnalysisWhereUniqueInput
  }

  /**
   * AiAnalysis findFirst
   */
  export type AiAnalysisFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter, which AiAnalysis to fetch.
     */
    where?: AiAnalysisWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AiAnalyses to fetch.
     */
    orderBy?: AiAnalysisOrderByWithRelationInput | AiAnalysisOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AiAnalyses.
     */
    cursor?: AiAnalysisWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AiAnalyses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AiAnalyses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AiAnalyses.
     */
    distinct?: AiAnalysisScalarFieldEnum | AiAnalysisScalarFieldEnum[]
  }

  /**
   * AiAnalysis findFirstOrThrow
   */
  export type AiAnalysisFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter, which AiAnalysis to fetch.
     */
    where?: AiAnalysisWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AiAnalyses to fetch.
     */
    orderBy?: AiAnalysisOrderByWithRelationInput | AiAnalysisOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for AiAnalyses.
     */
    cursor?: AiAnalysisWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AiAnalyses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AiAnalyses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AiAnalyses.
     */
    distinct?: AiAnalysisScalarFieldEnum | AiAnalysisScalarFieldEnum[]
  }

  /**
   * AiAnalysis findMany
   */
  export type AiAnalysisFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter, which AiAnalyses to fetch.
     */
    where?: AiAnalysisWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of AiAnalyses to fetch.
     */
    orderBy?: AiAnalysisOrderByWithRelationInput | AiAnalysisOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing AiAnalyses.
     */
    cursor?: AiAnalysisWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` AiAnalyses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` AiAnalyses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of AiAnalyses.
     */
    distinct?: AiAnalysisScalarFieldEnum | AiAnalysisScalarFieldEnum[]
  }

  /**
   * AiAnalysis create
   */
  export type AiAnalysisCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * The data needed to create a AiAnalysis.
     */
    data: XOR<AiAnalysisCreateInput, AiAnalysisUncheckedCreateInput>
  }

  /**
   * AiAnalysis createMany
   */
  export type AiAnalysisCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many AiAnalyses.
     */
    data: AiAnalysisCreateManyInput | AiAnalysisCreateManyInput[]
  }

  /**
   * AiAnalysis createManyAndReturn
   */
  export type AiAnalysisCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * The data used to create many AiAnalyses.
     */
    data: AiAnalysisCreateManyInput | AiAnalysisCreateManyInput[]
  }

  /**
   * AiAnalysis update
   */
  export type AiAnalysisUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * The data needed to update a AiAnalysis.
     */
    data: XOR<AiAnalysisUpdateInput, AiAnalysisUncheckedUpdateInput>
    /**
     * Choose, which AiAnalysis to update.
     */
    where: AiAnalysisWhereUniqueInput
  }

  /**
   * AiAnalysis updateMany
   */
  export type AiAnalysisUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update AiAnalyses.
     */
    data: XOR<AiAnalysisUpdateManyMutationInput, AiAnalysisUncheckedUpdateManyInput>
    /**
     * Filter which AiAnalyses to update
     */
    where?: AiAnalysisWhereInput
    /**
     * Limit how many AiAnalyses to update.
     */
    limit?: number
  }

  /**
   * AiAnalysis updateManyAndReturn
   */
  export type AiAnalysisUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * The data used to update AiAnalyses.
     */
    data: XOR<AiAnalysisUpdateManyMutationInput, AiAnalysisUncheckedUpdateManyInput>
    /**
     * Filter which AiAnalyses to update
     */
    where?: AiAnalysisWhereInput
    /**
     * Limit how many AiAnalyses to update.
     */
    limit?: number
  }

  /**
   * AiAnalysis upsert
   */
  export type AiAnalysisUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * The filter to search for the AiAnalysis to update in case it exists.
     */
    where: AiAnalysisWhereUniqueInput
    /**
     * In case the AiAnalysis found by the `where` argument doesn't exist, create a new AiAnalysis with this data.
     */
    create: XOR<AiAnalysisCreateInput, AiAnalysisUncheckedCreateInput>
    /**
     * In case the AiAnalysis was found with the provided `where` argument, update it with this data.
     */
    update: XOR<AiAnalysisUpdateInput, AiAnalysisUncheckedUpdateInput>
  }

  /**
   * AiAnalysis delete
   */
  export type AiAnalysisDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
    /**
     * Filter which AiAnalysis to delete.
     */
    where: AiAnalysisWhereUniqueInput
  }

  /**
   * AiAnalysis deleteMany
   */
  export type AiAnalysisDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which AiAnalyses to delete
     */
    where?: AiAnalysisWhereInput
    /**
     * Limit how many AiAnalyses to delete.
     */
    limit?: number
  }

  /**
   * AiAnalysis without action
   */
  export type AiAnalysisDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the AiAnalysis
     */
    select?: AiAnalysisSelect<ExtArgs> | null
    /**
     * Omit specific fields from the AiAnalysis
     */
    omit?: AiAnalysisOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const EventScalarFieldEnum: {
    id: 'id',
    rawItemId: 'rawItemId',
    titleOriginal: 'titleOriginal',
    titleCn: 'titleCn',
    titleLang: 'titleLang',
    summaryOriginal: 'summaryOriginal',
    summaryCn: 'summaryCn',
    contentOriginal: 'contentOriginal',
    contentCn: 'contentCn',
    contentHint: 'contentHint',
    contentType: 'contentType',
    url: 'url',
    permalink: 'permalink',
    sourceId: 'sourceId',
    sourceName: 'sourceName',
    sourceLevel: 'sourceLevel',
    sourceCountry: 'sourceCountry',
    sourceFeed: 'sourceFeed',
    sourceDesc: 'sourceDesc',
    category: 'category',
    subCategory: 'subCategory',
    tags: 'tags',
    affectedRegions: 'affectedRegions',
    scores: 'scores',
    finalScore: 'finalScore',
    importance: 'importance',
    aiStatus: 'aiStatus',
    aiModel: 'aiModel',
    aiTranslateModel: 'aiTranslateModel',
    aiReason: 'aiReason',
    aiCost: 'aiCost',
    aiAnalyzedAt: 'aiAnalyzedAt',
    selected: 'selected',
    isLead: 'isLead',
    publishedAt: 'publishedAt',
    crawledAt: 'crawledAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt',
    isSocial: 'isSocial',
    readCount: 'readCount',
    likeCount: 'likeCount',
    coverUrl: 'coverUrl',
    clusterId: 'clusterId',
    clusterSize: 'clusterSize'
  };

  export type EventScalarFieldEnum = (typeof EventScalarFieldEnum)[keyof typeof EventScalarFieldEnum]


  export const SourceScalarFieldEnum: {
    id: 'id',
    name: 'name',
    nameEn: 'nameEn',
    type: 'type',
    country: 'country',
    region: 'region',
    level: 'level',
    enabled: 'enabled',
    endpoints: 'endpoints',
    config: 'config',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SourceScalarFieldEnum = (typeof SourceScalarFieldEnum)[keyof typeof SourceScalarFieldEnum]


  export const CrawlLogScalarFieldEnum: {
    id: 'id',
    sourceId: 'sourceId',
    startedAt: 'startedAt',
    finishedAt: 'finishedAt',
    status: 'status',
    itemsTotal: 'itemsTotal',
    itemsNew: 'itemsNew',
    itemsDup: 'itemsDup',
    errorMsg: 'errorMsg',
    durationMs: 'durationMs',
    createdAt: 'createdAt'
  };

  export type CrawlLogScalarFieldEnum = (typeof CrawlLogScalarFieldEnum)[keyof typeof CrawlLogScalarFieldEnum]


  export const AiAnalysisScalarFieldEnum: {
    id: 'id',
    eventId: 'eventId',
    model: 'model',
    task: 'task',
    inputTokens: 'inputTokens',
    outputTokens: 'outputTokens',
    cost: 'cost',
    durationMs: 'durationMs',
    status: 'status',
    errorMsg: 'errorMsg',
    createdAt: 'createdAt'
  };

  export type AiAnalysisScalarFieldEnum = (typeof AiAnalysisScalarFieldEnum)[keyof typeof AiAnalysisScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    
  /**
   * Deep Input Types
   */


  export type EventWhereInput = {
    AND?: EventWhereInput | EventWhereInput[]
    OR?: EventWhereInput[]
    NOT?: EventWhereInput | EventWhereInput[]
    id?: StringFilter<"Event"> | string
    rawItemId?: StringFilter<"Event"> | string
    titleOriginal?: StringFilter<"Event"> | string
    titleCn?: StringFilter<"Event"> | string
    titleLang?: StringFilter<"Event"> | string
    summaryOriginal?: StringFilter<"Event"> | string
    summaryCn?: StringFilter<"Event"> | string
    contentOriginal?: StringNullableFilter<"Event"> | string | null
    contentCn?: StringNullableFilter<"Event"> | string | null
    contentHint?: StringNullableFilter<"Event"> | string | null
    contentType?: StringFilter<"Event"> | string
    url?: StringFilter<"Event"> | string
    permalink?: StringFilter<"Event"> | string
    sourceId?: StringFilter<"Event"> | string
    sourceName?: StringFilter<"Event"> | string
    sourceLevel?: StringFilter<"Event"> | string
    sourceCountry?: StringFilter<"Event"> | string
    sourceFeed?: StringFilter<"Event"> | string
    sourceDesc?: StringFilter<"Event"> | string
    category?: StringFilter<"Event"> | string
    subCategory?: StringFilter<"Event"> | string
    tags?: StringFilter<"Event"> | string
    affectedRegions?: StringFilter<"Event"> | string
    scores?: StringFilter<"Event"> | string
    finalScore?: FloatFilter<"Event"> | number
    importance?: IntFilter<"Event"> | number
    aiStatus?: StringFilter<"Event"> | string
    aiModel?: StringFilter<"Event"> | string
    aiTranslateModel?: StringFilter<"Event"> | string
    aiReason?: StringFilter<"Event"> | string
    aiCost?: FloatFilter<"Event"> | number
    aiAnalyzedAt?: StringNullableFilter<"Event"> | string | null
    selected?: IntFilter<"Event"> | number
    isLead?: IntFilter<"Event"> | number
    publishedAt?: StringFilter<"Event"> | string
    crawledAt?: StringFilter<"Event"> | string
    createdAt?: StringFilter<"Event"> | string
    updatedAt?: StringFilter<"Event"> | string
    isSocial?: IntFilter<"Event"> | number
    readCount?: IntFilter<"Event"> | number
    likeCount?: IntFilter<"Event"> | number
    coverUrl?: StringFilter<"Event"> | string
    clusterId?: StringNullableFilter<"Event"> | string | null
    clusterSize?: IntFilter<"Event"> | number
  }

  export type EventOrderByWithRelationInput = {
    id?: SortOrder
    rawItemId?: SortOrder
    titleOriginal?: SortOrder
    titleCn?: SortOrder
    titleLang?: SortOrder
    summaryOriginal?: SortOrder
    summaryCn?: SortOrder
    contentOriginal?: SortOrderInput | SortOrder
    contentCn?: SortOrderInput | SortOrder
    contentHint?: SortOrderInput | SortOrder
    contentType?: SortOrder
    url?: SortOrder
    permalink?: SortOrder
    sourceId?: SortOrder
    sourceName?: SortOrder
    sourceLevel?: SortOrder
    sourceCountry?: SortOrder
    sourceFeed?: SortOrder
    sourceDesc?: SortOrder
    category?: SortOrder
    subCategory?: SortOrder
    tags?: SortOrder
    affectedRegions?: SortOrder
    scores?: SortOrder
    finalScore?: SortOrder
    importance?: SortOrder
    aiStatus?: SortOrder
    aiModel?: SortOrder
    aiTranslateModel?: SortOrder
    aiReason?: SortOrder
    aiCost?: SortOrder
    aiAnalyzedAt?: SortOrderInput | SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    publishedAt?: SortOrder
    crawledAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    coverUrl?: SortOrder
    clusterId?: SortOrderInput | SortOrder
    clusterSize?: SortOrder
  }

  export type EventWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    url?: string
    AND?: EventWhereInput | EventWhereInput[]
    OR?: EventWhereInput[]
    NOT?: EventWhereInput | EventWhereInput[]
    rawItemId?: StringFilter<"Event"> | string
    titleOriginal?: StringFilter<"Event"> | string
    titleCn?: StringFilter<"Event"> | string
    titleLang?: StringFilter<"Event"> | string
    summaryOriginal?: StringFilter<"Event"> | string
    summaryCn?: StringFilter<"Event"> | string
    contentOriginal?: StringNullableFilter<"Event"> | string | null
    contentCn?: StringNullableFilter<"Event"> | string | null
    contentHint?: StringNullableFilter<"Event"> | string | null
    contentType?: StringFilter<"Event"> | string
    permalink?: StringFilter<"Event"> | string
    sourceId?: StringFilter<"Event"> | string
    sourceName?: StringFilter<"Event"> | string
    sourceLevel?: StringFilter<"Event"> | string
    sourceCountry?: StringFilter<"Event"> | string
    sourceFeed?: StringFilter<"Event"> | string
    sourceDesc?: StringFilter<"Event"> | string
    category?: StringFilter<"Event"> | string
    subCategory?: StringFilter<"Event"> | string
    tags?: StringFilter<"Event"> | string
    affectedRegions?: StringFilter<"Event"> | string
    scores?: StringFilter<"Event"> | string
    finalScore?: FloatFilter<"Event"> | number
    importance?: IntFilter<"Event"> | number
    aiStatus?: StringFilter<"Event"> | string
    aiModel?: StringFilter<"Event"> | string
    aiTranslateModel?: StringFilter<"Event"> | string
    aiReason?: StringFilter<"Event"> | string
    aiCost?: FloatFilter<"Event"> | number
    aiAnalyzedAt?: StringNullableFilter<"Event"> | string | null
    selected?: IntFilter<"Event"> | number
    isLead?: IntFilter<"Event"> | number
    publishedAt?: StringFilter<"Event"> | string
    crawledAt?: StringFilter<"Event"> | string
    createdAt?: StringFilter<"Event"> | string
    updatedAt?: StringFilter<"Event"> | string
    isSocial?: IntFilter<"Event"> | number
    readCount?: IntFilter<"Event"> | number
    likeCount?: IntFilter<"Event"> | number
    coverUrl?: StringFilter<"Event"> | string
    clusterId?: StringNullableFilter<"Event"> | string | null
    clusterSize?: IntFilter<"Event"> | number
  }, "id" | "url">

  export type EventOrderByWithAggregationInput = {
    id?: SortOrder
    rawItemId?: SortOrder
    titleOriginal?: SortOrder
    titleCn?: SortOrder
    titleLang?: SortOrder
    summaryOriginal?: SortOrder
    summaryCn?: SortOrder
    contentOriginal?: SortOrderInput | SortOrder
    contentCn?: SortOrderInput | SortOrder
    contentHint?: SortOrderInput | SortOrder
    contentType?: SortOrder
    url?: SortOrder
    permalink?: SortOrder
    sourceId?: SortOrder
    sourceName?: SortOrder
    sourceLevel?: SortOrder
    sourceCountry?: SortOrder
    sourceFeed?: SortOrder
    sourceDesc?: SortOrder
    category?: SortOrder
    subCategory?: SortOrder
    tags?: SortOrder
    affectedRegions?: SortOrder
    scores?: SortOrder
    finalScore?: SortOrder
    importance?: SortOrder
    aiStatus?: SortOrder
    aiModel?: SortOrder
    aiTranslateModel?: SortOrder
    aiReason?: SortOrder
    aiCost?: SortOrder
    aiAnalyzedAt?: SortOrderInput | SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    publishedAt?: SortOrder
    crawledAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    coverUrl?: SortOrder
    clusterId?: SortOrderInput | SortOrder
    clusterSize?: SortOrder
    _count?: EventCountOrderByAggregateInput
    _avg?: EventAvgOrderByAggregateInput
    _max?: EventMaxOrderByAggregateInput
    _min?: EventMinOrderByAggregateInput
    _sum?: EventSumOrderByAggregateInput
  }

  export type EventScalarWhereWithAggregatesInput = {
    AND?: EventScalarWhereWithAggregatesInput | EventScalarWhereWithAggregatesInput[]
    OR?: EventScalarWhereWithAggregatesInput[]
    NOT?: EventScalarWhereWithAggregatesInput | EventScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Event"> | string
    rawItemId?: StringWithAggregatesFilter<"Event"> | string
    titleOriginal?: StringWithAggregatesFilter<"Event"> | string
    titleCn?: StringWithAggregatesFilter<"Event"> | string
    titleLang?: StringWithAggregatesFilter<"Event"> | string
    summaryOriginal?: StringWithAggregatesFilter<"Event"> | string
    summaryCn?: StringWithAggregatesFilter<"Event"> | string
    contentOriginal?: StringNullableWithAggregatesFilter<"Event"> | string | null
    contentCn?: StringNullableWithAggregatesFilter<"Event"> | string | null
    contentHint?: StringNullableWithAggregatesFilter<"Event"> | string | null
    contentType?: StringWithAggregatesFilter<"Event"> | string
    url?: StringWithAggregatesFilter<"Event"> | string
    permalink?: StringWithAggregatesFilter<"Event"> | string
    sourceId?: StringWithAggregatesFilter<"Event"> | string
    sourceName?: StringWithAggregatesFilter<"Event"> | string
    sourceLevel?: StringWithAggregatesFilter<"Event"> | string
    sourceCountry?: StringWithAggregatesFilter<"Event"> | string
    sourceFeed?: StringWithAggregatesFilter<"Event"> | string
    sourceDesc?: StringWithAggregatesFilter<"Event"> | string
    category?: StringWithAggregatesFilter<"Event"> | string
    subCategory?: StringWithAggregatesFilter<"Event"> | string
    tags?: StringWithAggregatesFilter<"Event"> | string
    affectedRegions?: StringWithAggregatesFilter<"Event"> | string
    scores?: StringWithAggregatesFilter<"Event"> | string
    finalScore?: FloatWithAggregatesFilter<"Event"> | number
    importance?: IntWithAggregatesFilter<"Event"> | number
    aiStatus?: StringWithAggregatesFilter<"Event"> | string
    aiModel?: StringWithAggregatesFilter<"Event"> | string
    aiTranslateModel?: StringWithAggregatesFilter<"Event"> | string
    aiReason?: StringWithAggregatesFilter<"Event"> | string
    aiCost?: FloatWithAggregatesFilter<"Event"> | number
    aiAnalyzedAt?: StringNullableWithAggregatesFilter<"Event"> | string | null
    selected?: IntWithAggregatesFilter<"Event"> | number
    isLead?: IntWithAggregatesFilter<"Event"> | number
    publishedAt?: StringWithAggregatesFilter<"Event"> | string
    crawledAt?: StringWithAggregatesFilter<"Event"> | string
    createdAt?: StringWithAggregatesFilter<"Event"> | string
    updatedAt?: StringWithAggregatesFilter<"Event"> | string
    isSocial?: IntWithAggregatesFilter<"Event"> | number
    readCount?: IntWithAggregatesFilter<"Event"> | number
    likeCount?: IntWithAggregatesFilter<"Event"> | number
    coverUrl?: StringWithAggregatesFilter<"Event"> | string
    clusterId?: StringNullableWithAggregatesFilter<"Event"> | string | null
    clusterSize?: IntWithAggregatesFilter<"Event"> | number
  }

  export type SourceWhereInput = {
    AND?: SourceWhereInput | SourceWhereInput[]
    OR?: SourceWhereInput[]
    NOT?: SourceWhereInput | SourceWhereInput[]
    id?: StringFilter<"Source"> | string
    name?: StringFilter<"Source"> | string
    nameEn?: StringFilter<"Source"> | string
    type?: StringFilter<"Source"> | string
    country?: StringFilter<"Source"> | string
    region?: StringFilter<"Source"> | string
    level?: StringFilter<"Source"> | string
    enabled?: IntFilter<"Source"> | number
    endpoints?: StringFilter<"Source"> | string
    config?: StringFilter<"Source"> | string
    createdAt?: StringFilter<"Source"> | string
    updatedAt?: StringFilter<"Source"> | string
  }

  export type SourceOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    nameEn?: SortOrder
    type?: SortOrder
    country?: SortOrder
    region?: SortOrder
    level?: SortOrder
    enabled?: SortOrder
    endpoints?: SortOrder
    config?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SourceWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: SourceWhereInput | SourceWhereInput[]
    OR?: SourceWhereInput[]
    NOT?: SourceWhereInput | SourceWhereInput[]
    name?: StringFilter<"Source"> | string
    nameEn?: StringFilter<"Source"> | string
    type?: StringFilter<"Source"> | string
    country?: StringFilter<"Source"> | string
    region?: StringFilter<"Source"> | string
    level?: StringFilter<"Source"> | string
    enabled?: IntFilter<"Source"> | number
    endpoints?: StringFilter<"Source"> | string
    config?: StringFilter<"Source"> | string
    createdAt?: StringFilter<"Source"> | string
    updatedAt?: StringFilter<"Source"> | string
  }, "id">

  export type SourceOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    nameEn?: SortOrder
    type?: SortOrder
    country?: SortOrder
    region?: SortOrder
    level?: SortOrder
    enabled?: SortOrder
    endpoints?: SortOrder
    config?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SourceCountOrderByAggregateInput
    _avg?: SourceAvgOrderByAggregateInput
    _max?: SourceMaxOrderByAggregateInput
    _min?: SourceMinOrderByAggregateInput
    _sum?: SourceSumOrderByAggregateInput
  }

  export type SourceScalarWhereWithAggregatesInput = {
    AND?: SourceScalarWhereWithAggregatesInput | SourceScalarWhereWithAggregatesInput[]
    OR?: SourceScalarWhereWithAggregatesInput[]
    NOT?: SourceScalarWhereWithAggregatesInput | SourceScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Source"> | string
    name?: StringWithAggregatesFilter<"Source"> | string
    nameEn?: StringWithAggregatesFilter<"Source"> | string
    type?: StringWithAggregatesFilter<"Source"> | string
    country?: StringWithAggregatesFilter<"Source"> | string
    region?: StringWithAggregatesFilter<"Source"> | string
    level?: StringWithAggregatesFilter<"Source"> | string
    enabled?: IntWithAggregatesFilter<"Source"> | number
    endpoints?: StringWithAggregatesFilter<"Source"> | string
    config?: StringWithAggregatesFilter<"Source"> | string
    createdAt?: StringWithAggregatesFilter<"Source"> | string
    updatedAt?: StringWithAggregatesFilter<"Source"> | string
  }

  export type CrawlLogWhereInput = {
    AND?: CrawlLogWhereInput | CrawlLogWhereInput[]
    OR?: CrawlLogWhereInput[]
    NOT?: CrawlLogWhereInput | CrawlLogWhereInput[]
    id?: IntFilter<"CrawlLog"> | number
    sourceId?: StringFilter<"CrawlLog"> | string
    startedAt?: StringFilter<"CrawlLog"> | string
    finishedAt?: StringNullableFilter<"CrawlLog"> | string | null
    status?: StringFilter<"CrawlLog"> | string
    itemsTotal?: IntFilter<"CrawlLog"> | number
    itemsNew?: IntFilter<"CrawlLog"> | number
    itemsDup?: IntFilter<"CrawlLog"> | number
    errorMsg?: StringNullableFilter<"CrawlLog"> | string | null
    durationMs?: IntNullableFilter<"CrawlLog"> | number | null
    createdAt?: StringFilter<"CrawlLog"> | string
  }

  export type CrawlLogOrderByWithRelationInput = {
    id?: SortOrder
    sourceId?: SortOrder
    startedAt?: SortOrder
    finishedAt?: SortOrderInput | SortOrder
    status?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    errorMsg?: SortOrderInput | SortOrder
    durationMs?: SortOrderInput | SortOrder
    createdAt?: SortOrder
  }

  export type CrawlLogWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: CrawlLogWhereInput | CrawlLogWhereInput[]
    OR?: CrawlLogWhereInput[]
    NOT?: CrawlLogWhereInput | CrawlLogWhereInput[]
    sourceId?: StringFilter<"CrawlLog"> | string
    startedAt?: StringFilter<"CrawlLog"> | string
    finishedAt?: StringNullableFilter<"CrawlLog"> | string | null
    status?: StringFilter<"CrawlLog"> | string
    itemsTotal?: IntFilter<"CrawlLog"> | number
    itemsNew?: IntFilter<"CrawlLog"> | number
    itemsDup?: IntFilter<"CrawlLog"> | number
    errorMsg?: StringNullableFilter<"CrawlLog"> | string | null
    durationMs?: IntNullableFilter<"CrawlLog"> | number | null
    createdAt?: StringFilter<"CrawlLog"> | string
  }, "id">

  export type CrawlLogOrderByWithAggregationInput = {
    id?: SortOrder
    sourceId?: SortOrder
    startedAt?: SortOrder
    finishedAt?: SortOrderInput | SortOrder
    status?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    errorMsg?: SortOrderInput | SortOrder
    durationMs?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: CrawlLogCountOrderByAggregateInput
    _avg?: CrawlLogAvgOrderByAggregateInput
    _max?: CrawlLogMaxOrderByAggregateInput
    _min?: CrawlLogMinOrderByAggregateInput
    _sum?: CrawlLogSumOrderByAggregateInput
  }

  export type CrawlLogScalarWhereWithAggregatesInput = {
    AND?: CrawlLogScalarWhereWithAggregatesInput | CrawlLogScalarWhereWithAggregatesInput[]
    OR?: CrawlLogScalarWhereWithAggregatesInput[]
    NOT?: CrawlLogScalarWhereWithAggregatesInput | CrawlLogScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"CrawlLog"> | number
    sourceId?: StringWithAggregatesFilter<"CrawlLog"> | string
    startedAt?: StringWithAggregatesFilter<"CrawlLog"> | string
    finishedAt?: StringNullableWithAggregatesFilter<"CrawlLog"> | string | null
    status?: StringWithAggregatesFilter<"CrawlLog"> | string
    itemsTotal?: IntWithAggregatesFilter<"CrawlLog"> | number
    itemsNew?: IntWithAggregatesFilter<"CrawlLog"> | number
    itemsDup?: IntWithAggregatesFilter<"CrawlLog"> | number
    errorMsg?: StringNullableWithAggregatesFilter<"CrawlLog"> | string | null
    durationMs?: IntNullableWithAggregatesFilter<"CrawlLog"> | number | null
    createdAt?: StringWithAggregatesFilter<"CrawlLog"> | string
  }

  export type AiAnalysisWhereInput = {
    AND?: AiAnalysisWhereInput | AiAnalysisWhereInput[]
    OR?: AiAnalysisWhereInput[]
    NOT?: AiAnalysisWhereInput | AiAnalysisWhereInput[]
    id?: IntFilter<"AiAnalysis"> | number
    eventId?: StringFilter<"AiAnalysis"> | string
    model?: StringFilter<"AiAnalysis"> | string
    task?: StringFilter<"AiAnalysis"> | string
    inputTokens?: IntFilter<"AiAnalysis"> | number
    outputTokens?: IntFilter<"AiAnalysis"> | number
    cost?: FloatFilter<"AiAnalysis"> | number
    durationMs?: IntNullableFilter<"AiAnalysis"> | number | null
    status?: StringFilter<"AiAnalysis"> | string
    errorMsg?: StringNullableFilter<"AiAnalysis"> | string | null
    createdAt?: StringFilter<"AiAnalysis"> | string
  }

  export type AiAnalysisOrderByWithRelationInput = {
    id?: SortOrder
    eventId?: SortOrder
    model?: SortOrder
    task?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrderInput | SortOrder
    status?: SortOrder
    errorMsg?: SortOrderInput | SortOrder
    createdAt?: SortOrder
  }

  export type AiAnalysisWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: AiAnalysisWhereInput | AiAnalysisWhereInput[]
    OR?: AiAnalysisWhereInput[]
    NOT?: AiAnalysisWhereInput | AiAnalysisWhereInput[]
    eventId?: StringFilter<"AiAnalysis"> | string
    model?: StringFilter<"AiAnalysis"> | string
    task?: StringFilter<"AiAnalysis"> | string
    inputTokens?: IntFilter<"AiAnalysis"> | number
    outputTokens?: IntFilter<"AiAnalysis"> | number
    cost?: FloatFilter<"AiAnalysis"> | number
    durationMs?: IntNullableFilter<"AiAnalysis"> | number | null
    status?: StringFilter<"AiAnalysis"> | string
    errorMsg?: StringNullableFilter<"AiAnalysis"> | string | null
    createdAt?: StringFilter<"AiAnalysis"> | string
  }, "id">

  export type AiAnalysisOrderByWithAggregationInput = {
    id?: SortOrder
    eventId?: SortOrder
    model?: SortOrder
    task?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrderInput | SortOrder
    status?: SortOrder
    errorMsg?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: AiAnalysisCountOrderByAggregateInput
    _avg?: AiAnalysisAvgOrderByAggregateInput
    _max?: AiAnalysisMaxOrderByAggregateInput
    _min?: AiAnalysisMinOrderByAggregateInput
    _sum?: AiAnalysisSumOrderByAggregateInput
  }

  export type AiAnalysisScalarWhereWithAggregatesInput = {
    AND?: AiAnalysisScalarWhereWithAggregatesInput | AiAnalysisScalarWhereWithAggregatesInput[]
    OR?: AiAnalysisScalarWhereWithAggregatesInput[]
    NOT?: AiAnalysisScalarWhereWithAggregatesInput | AiAnalysisScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"AiAnalysis"> | number
    eventId?: StringWithAggregatesFilter<"AiAnalysis"> | string
    model?: StringWithAggregatesFilter<"AiAnalysis"> | string
    task?: StringWithAggregatesFilter<"AiAnalysis"> | string
    inputTokens?: IntWithAggregatesFilter<"AiAnalysis"> | number
    outputTokens?: IntWithAggregatesFilter<"AiAnalysis"> | number
    cost?: FloatWithAggregatesFilter<"AiAnalysis"> | number
    durationMs?: IntNullableWithAggregatesFilter<"AiAnalysis"> | number | null
    status?: StringWithAggregatesFilter<"AiAnalysis"> | string
    errorMsg?: StringNullableWithAggregatesFilter<"AiAnalysis"> | string | null
    createdAt?: StringWithAggregatesFilter<"AiAnalysis"> | string
  }

  export type EventCreateInput = {
    id: string
    rawItemId: string
    titleOriginal: string
    titleCn?: string
    titleLang: string
    summaryOriginal?: string
    summaryCn?: string
    contentOriginal?: string | null
    contentCn?: string | null
    contentHint?: string | null
    contentType?: string
    url: string
    permalink: string
    sourceId: string
    sourceName: string
    sourceLevel: string
    sourceCountry?: string
    sourceFeed?: string
    sourceDesc?: string
    category: string
    subCategory?: string
    tags?: string
    affectedRegions?: string
    scores?: string
    finalScore?: number
    importance?: number
    aiStatus?: string
    aiModel?: string
    aiTranslateModel?: string
    aiReason?: string
    aiCost?: number
    aiAnalyzedAt?: string | null
    selected?: number
    isLead?: number
    publishedAt: string
    crawledAt: string
    createdAt?: string
    updatedAt?: string
    isSocial?: number
    readCount?: number
    likeCount?: number
    coverUrl?: string
    clusterId?: string | null
    clusterSize?: number
  }

  export type EventUncheckedCreateInput = {
    id: string
    rawItemId: string
    titleOriginal: string
    titleCn?: string
    titleLang: string
    summaryOriginal?: string
    summaryCn?: string
    contentOriginal?: string | null
    contentCn?: string | null
    contentHint?: string | null
    contentType?: string
    url: string
    permalink: string
    sourceId: string
    sourceName: string
    sourceLevel: string
    sourceCountry?: string
    sourceFeed?: string
    sourceDesc?: string
    category: string
    subCategory?: string
    tags?: string
    affectedRegions?: string
    scores?: string
    finalScore?: number
    importance?: number
    aiStatus?: string
    aiModel?: string
    aiTranslateModel?: string
    aiReason?: string
    aiCost?: number
    aiAnalyzedAt?: string | null
    selected?: number
    isLead?: number
    publishedAt: string
    crawledAt: string
    createdAt?: string
    updatedAt?: string
    isSocial?: number
    readCount?: number
    likeCount?: number
    coverUrl?: string
    clusterId?: string | null
    clusterSize?: number
  }

  export type EventUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    rawItemId?: StringFieldUpdateOperationsInput | string
    titleOriginal?: StringFieldUpdateOperationsInput | string
    titleCn?: StringFieldUpdateOperationsInput | string
    titleLang?: StringFieldUpdateOperationsInput | string
    summaryOriginal?: StringFieldUpdateOperationsInput | string
    summaryCn?: StringFieldUpdateOperationsInput | string
    contentOriginal?: NullableStringFieldUpdateOperationsInput | string | null
    contentCn?: NullableStringFieldUpdateOperationsInput | string | null
    contentHint?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    permalink?: StringFieldUpdateOperationsInput | string
    sourceId?: StringFieldUpdateOperationsInput | string
    sourceName?: StringFieldUpdateOperationsInput | string
    sourceLevel?: StringFieldUpdateOperationsInput | string
    sourceCountry?: StringFieldUpdateOperationsInput | string
    sourceFeed?: StringFieldUpdateOperationsInput | string
    sourceDesc?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    subCategory?: StringFieldUpdateOperationsInput | string
    tags?: StringFieldUpdateOperationsInput | string
    affectedRegions?: StringFieldUpdateOperationsInput | string
    scores?: StringFieldUpdateOperationsInput | string
    finalScore?: FloatFieldUpdateOperationsInput | number
    importance?: IntFieldUpdateOperationsInput | number
    aiStatus?: StringFieldUpdateOperationsInput | string
    aiModel?: StringFieldUpdateOperationsInput | string
    aiTranslateModel?: StringFieldUpdateOperationsInput | string
    aiReason?: StringFieldUpdateOperationsInput | string
    aiCost?: FloatFieldUpdateOperationsInput | number
    aiAnalyzedAt?: NullableStringFieldUpdateOperationsInput | string | null
    selected?: IntFieldUpdateOperationsInput | number
    isLead?: IntFieldUpdateOperationsInput | number
    publishedAt?: StringFieldUpdateOperationsInput | string
    crawledAt?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
    isSocial?: IntFieldUpdateOperationsInput | number
    readCount?: IntFieldUpdateOperationsInput | number
    likeCount?: IntFieldUpdateOperationsInput | number
    coverUrl?: StringFieldUpdateOperationsInput | string
    clusterId?: NullableStringFieldUpdateOperationsInput | string | null
    clusterSize?: IntFieldUpdateOperationsInput | number
  }

  export type EventUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    rawItemId?: StringFieldUpdateOperationsInput | string
    titleOriginal?: StringFieldUpdateOperationsInput | string
    titleCn?: StringFieldUpdateOperationsInput | string
    titleLang?: StringFieldUpdateOperationsInput | string
    summaryOriginal?: StringFieldUpdateOperationsInput | string
    summaryCn?: StringFieldUpdateOperationsInput | string
    contentOriginal?: NullableStringFieldUpdateOperationsInput | string | null
    contentCn?: NullableStringFieldUpdateOperationsInput | string | null
    contentHint?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    permalink?: StringFieldUpdateOperationsInput | string
    sourceId?: StringFieldUpdateOperationsInput | string
    sourceName?: StringFieldUpdateOperationsInput | string
    sourceLevel?: StringFieldUpdateOperationsInput | string
    sourceCountry?: StringFieldUpdateOperationsInput | string
    sourceFeed?: StringFieldUpdateOperationsInput | string
    sourceDesc?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    subCategory?: StringFieldUpdateOperationsInput | string
    tags?: StringFieldUpdateOperationsInput | string
    affectedRegions?: StringFieldUpdateOperationsInput | string
    scores?: StringFieldUpdateOperationsInput | string
    finalScore?: FloatFieldUpdateOperationsInput | number
    importance?: IntFieldUpdateOperationsInput | number
    aiStatus?: StringFieldUpdateOperationsInput | string
    aiModel?: StringFieldUpdateOperationsInput | string
    aiTranslateModel?: StringFieldUpdateOperationsInput | string
    aiReason?: StringFieldUpdateOperationsInput | string
    aiCost?: FloatFieldUpdateOperationsInput | number
    aiAnalyzedAt?: NullableStringFieldUpdateOperationsInput | string | null
    selected?: IntFieldUpdateOperationsInput | number
    isLead?: IntFieldUpdateOperationsInput | number
    publishedAt?: StringFieldUpdateOperationsInput | string
    crawledAt?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
    isSocial?: IntFieldUpdateOperationsInput | number
    readCount?: IntFieldUpdateOperationsInput | number
    likeCount?: IntFieldUpdateOperationsInput | number
    coverUrl?: StringFieldUpdateOperationsInput | string
    clusterId?: NullableStringFieldUpdateOperationsInput | string | null
    clusterSize?: IntFieldUpdateOperationsInput | number
  }

  export type EventCreateManyInput = {
    id: string
    rawItemId: string
    titleOriginal: string
    titleCn?: string
    titleLang: string
    summaryOriginal?: string
    summaryCn?: string
    contentOriginal?: string | null
    contentCn?: string | null
    contentHint?: string | null
    contentType?: string
    url: string
    permalink: string
    sourceId: string
    sourceName: string
    sourceLevel: string
    sourceCountry?: string
    sourceFeed?: string
    sourceDesc?: string
    category: string
    subCategory?: string
    tags?: string
    affectedRegions?: string
    scores?: string
    finalScore?: number
    importance?: number
    aiStatus?: string
    aiModel?: string
    aiTranslateModel?: string
    aiReason?: string
    aiCost?: number
    aiAnalyzedAt?: string | null
    selected?: number
    isLead?: number
    publishedAt: string
    crawledAt: string
    createdAt?: string
    updatedAt?: string
    isSocial?: number
    readCount?: number
    likeCount?: number
    coverUrl?: string
    clusterId?: string | null
    clusterSize?: number
  }

  export type EventUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    rawItemId?: StringFieldUpdateOperationsInput | string
    titleOriginal?: StringFieldUpdateOperationsInput | string
    titleCn?: StringFieldUpdateOperationsInput | string
    titleLang?: StringFieldUpdateOperationsInput | string
    summaryOriginal?: StringFieldUpdateOperationsInput | string
    summaryCn?: StringFieldUpdateOperationsInput | string
    contentOriginal?: NullableStringFieldUpdateOperationsInput | string | null
    contentCn?: NullableStringFieldUpdateOperationsInput | string | null
    contentHint?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    permalink?: StringFieldUpdateOperationsInput | string
    sourceId?: StringFieldUpdateOperationsInput | string
    sourceName?: StringFieldUpdateOperationsInput | string
    sourceLevel?: StringFieldUpdateOperationsInput | string
    sourceCountry?: StringFieldUpdateOperationsInput | string
    sourceFeed?: StringFieldUpdateOperationsInput | string
    sourceDesc?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    subCategory?: StringFieldUpdateOperationsInput | string
    tags?: StringFieldUpdateOperationsInput | string
    affectedRegions?: StringFieldUpdateOperationsInput | string
    scores?: StringFieldUpdateOperationsInput | string
    finalScore?: FloatFieldUpdateOperationsInput | number
    importance?: IntFieldUpdateOperationsInput | number
    aiStatus?: StringFieldUpdateOperationsInput | string
    aiModel?: StringFieldUpdateOperationsInput | string
    aiTranslateModel?: StringFieldUpdateOperationsInput | string
    aiReason?: StringFieldUpdateOperationsInput | string
    aiCost?: FloatFieldUpdateOperationsInput | number
    aiAnalyzedAt?: NullableStringFieldUpdateOperationsInput | string | null
    selected?: IntFieldUpdateOperationsInput | number
    isLead?: IntFieldUpdateOperationsInput | number
    publishedAt?: StringFieldUpdateOperationsInput | string
    crawledAt?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
    isSocial?: IntFieldUpdateOperationsInput | number
    readCount?: IntFieldUpdateOperationsInput | number
    likeCount?: IntFieldUpdateOperationsInput | number
    coverUrl?: StringFieldUpdateOperationsInput | string
    clusterId?: NullableStringFieldUpdateOperationsInput | string | null
    clusterSize?: IntFieldUpdateOperationsInput | number
  }

  export type EventUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    rawItemId?: StringFieldUpdateOperationsInput | string
    titleOriginal?: StringFieldUpdateOperationsInput | string
    titleCn?: StringFieldUpdateOperationsInput | string
    titleLang?: StringFieldUpdateOperationsInput | string
    summaryOriginal?: StringFieldUpdateOperationsInput | string
    summaryCn?: StringFieldUpdateOperationsInput | string
    contentOriginal?: NullableStringFieldUpdateOperationsInput | string | null
    contentCn?: NullableStringFieldUpdateOperationsInput | string | null
    contentHint?: NullableStringFieldUpdateOperationsInput | string | null
    contentType?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    permalink?: StringFieldUpdateOperationsInput | string
    sourceId?: StringFieldUpdateOperationsInput | string
    sourceName?: StringFieldUpdateOperationsInput | string
    sourceLevel?: StringFieldUpdateOperationsInput | string
    sourceCountry?: StringFieldUpdateOperationsInput | string
    sourceFeed?: StringFieldUpdateOperationsInput | string
    sourceDesc?: StringFieldUpdateOperationsInput | string
    category?: StringFieldUpdateOperationsInput | string
    subCategory?: StringFieldUpdateOperationsInput | string
    tags?: StringFieldUpdateOperationsInput | string
    affectedRegions?: StringFieldUpdateOperationsInput | string
    scores?: StringFieldUpdateOperationsInput | string
    finalScore?: FloatFieldUpdateOperationsInput | number
    importance?: IntFieldUpdateOperationsInput | number
    aiStatus?: StringFieldUpdateOperationsInput | string
    aiModel?: StringFieldUpdateOperationsInput | string
    aiTranslateModel?: StringFieldUpdateOperationsInput | string
    aiReason?: StringFieldUpdateOperationsInput | string
    aiCost?: FloatFieldUpdateOperationsInput | number
    aiAnalyzedAt?: NullableStringFieldUpdateOperationsInput | string | null
    selected?: IntFieldUpdateOperationsInput | number
    isLead?: IntFieldUpdateOperationsInput | number
    publishedAt?: StringFieldUpdateOperationsInput | string
    crawledAt?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
    isSocial?: IntFieldUpdateOperationsInput | number
    readCount?: IntFieldUpdateOperationsInput | number
    likeCount?: IntFieldUpdateOperationsInput | number
    coverUrl?: StringFieldUpdateOperationsInput | string
    clusterId?: NullableStringFieldUpdateOperationsInput | string | null
    clusterSize?: IntFieldUpdateOperationsInput | number
  }

  export type SourceCreateInput = {
    id: string
    name: string
    nameEn?: string
    type: string
    country?: string
    region?: string
    level?: string
    enabled?: number
    endpoints?: string
    config?: string
    createdAt?: string
    updatedAt?: string
  }

  export type SourceUncheckedCreateInput = {
    id: string
    name: string
    nameEn?: string
    type: string
    country?: string
    region?: string
    level?: string
    enabled?: number
    endpoints?: string
    config?: string
    createdAt?: string
    updatedAt?: string
  }

  export type SourceUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    nameEn?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    country?: StringFieldUpdateOperationsInput | string
    region?: StringFieldUpdateOperationsInput | string
    level?: StringFieldUpdateOperationsInput | string
    enabled?: IntFieldUpdateOperationsInput | number
    endpoints?: StringFieldUpdateOperationsInput | string
    config?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
  }

  export type SourceUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    nameEn?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    country?: StringFieldUpdateOperationsInput | string
    region?: StringFieldUpdateOperationsInput | string
    level?: StringFieldUpdateOperationsInput | string
    enabled?: IntFieldUpdateOperationsInput | number
    endpoints?: StringFieldUpdateOperationsInput | string
    config?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
  }

  export type SourceCreateManyInput = {
    id: string
    name: string
    nameEn?: string
    type: string
    country?: string
    region?: string
    level?: string
    enabled?: number
    endpoints?: string
    config?: string
    createdAt?: string
    updatedAt?: string
  }

  export type SourceUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    nameEn?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    country?: StringFieldUpdateOperationsInput | string
    region?: StringFieldUpdateOperationsInput | string
    level?: StringFieldUpdateOperationsInput | string
    enabled?: IntFieldUpdateOperationsInput | number
    endpoints?: StringFieldUpdateOperationsInput | string
    config?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
  }

  export type SourceUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    nameEn?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    country?: StringFieldUpdateOperationsInput | string
    region?: StringFieldUpdateOperationsInput | string
    level?: StringFieldUpdateOperationsInput | string
    enabled?: IntFieldUpdateOperationsInput | number
    endpoints?: StringFieldUpdateOperationsInput | string
    config?: StringFieldUpdateOperationsInput | string
    createdAt?: StringFieldUpdateOperationsInput | string
    updatedAt?: StringFieldUpdateOperationsInput | string
  }

  export type CrawlLogCreateInput = {
    sourceId: string
    startedAt: string
    finishedAt?: string | null
    status?: string
    itemsTotal?: number
    itemsNew?: number
    itemsDup?: number
    errorMsg?: string | null
    durationMs?: number | null
    createdAt?: string
  }

  export type CrawlLogUncheckedCreateInput = {
    id?: number
    sourceId: string
    startedAt: string
    finishedAt?: string | null
    status?: string
    itemsTotal?: number
    itemsNew?: number
    itemsDup?: number
    errorMsg?: string | null
    durationMs?: number | null
    createdAt?: string
  }

  export type CrawlLogUpdateInput = {
    sourceId?: StringFieldUpdateOperationsInput | string
    startedAt?: StringFieldUpdateOperationsInput | string
    finishedAt?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    itemsTotal?: IntFieldUpdateOperationsInput | number
    itemsNew?: IntFieldUpdateOperationsInput | number
    itemsDup?: IntFieldUpdateOperationsInput | number
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type CrawlLogUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    sourceId?: StringFieldUpdateOperationsInput | string
    startedAt?: StringFieldUpdateOperationsInput | string
    finishedAt?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    itemsTotal?: IntFieldUpdateOperationsInput | number
    itemsNew?: IntFieldUpdateOperationsInput | number
    itemsDup?: IntFieldUpdateOperationsInput | number
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type CrawlLogCreateManyInput = {
    id?: number
    sourceId: string
    startedAt: string
    finishedAt?: string | null
    status?: string
    itemsTotal?: number
    itemsNew?: number
    itemsDup?: number
    errorMsg?: string | null
    durationMs?: number | null
    createdAt?: string
  }

  export type CrawlLogUpdateManyMutationInput = {
    sourceId?: StringFieldUpdateOperationsInput | string
    startedAt?: StringFieldUpdateOperationsInput | string
    finishedAt?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    itemsTotal?: IntFieldUpdateOperationsInput | number
    itemsNew?: IntFieldUpdateOperationsInput | number
    itemsDup?: IntFieldUpdateOperationsInput | number
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type CrawlLogUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    sourceId?: StringFieldUpdateOperationsInput | string
    startedAt?: StringFieldUpdateOperationsInput | string
    finishedAt?: NullableStringFieldUpdateOperationsInput | string | null
    status?: StringFieldUpdateOperationsInput | string
    itemsTotal?: IntFieldUpdateOperationsInput | number
    itemsNew?: IntFieldUpdateOperationsInput | number
    itemsDup?: IntFieldUpdateOperationsInput | number
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type AiAnalysisCreateInput = {
    eventId: string
    model: string
    task: string
    inputTokens?: number
    outputTokens?: number
    cost?: number
    durationMs?: number | null
    status?: string
    errorMsg?: string | null
    createdAt?: string
  }

  export type AiAnalysisUncheckedCreateInput = {
    id?: number
    eventId: string
    model: string
    task: string
    inputTokens?: number
    outputTokens?: number
    cost?: number
    durationMs?: number | null
    status?: string
    errorMsg?: string | null
    createdAt?: string
  }

  export type AiAnalysisUpdateInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    model?: StringFieldUpdateOperationsInput | string
    task?: StringFieldUpdateOperationsInput | string
    inputTokens?: IntFieldUpdateOperationsInput | number
    outputTokens?: IntFieldUpdateOperationsInput | number
    cost?: FloatFieldUpdateOperationsInput | number
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    status?: StringFieldUpdateOperationsInput | string
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type AiAnalysisUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    eventId?: StringFieldUpdateOperationsInput | string
    model?: StringFieldUpdateOperationsInput | string
    task?: StringFieldUpdateOperationsInput | string
    inputTokens?: IntFieldUpdateOperationsInput | number
    outputTokens?: IntFieldUpdateOperationsInput | number
    cost?: FloatFieldUpdateOperationsInput | number
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    status?: StringFieldUpdateOperationsInput | string
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type AiAnalysisCreateManyInput = {
    id?: number
    eventId: string
    model: string
    task: string
    inputTokens?: number
    outputTokens?: number
    cost?: number
    durationMs?: number | null
    status?: string
    errorMsg?: string | null
    createdAt?: string
  }

  export type AiAnalysisUpdateManyMutationInput = {
    eventId?: StringFieldUpdateOperationsInput | string
    model?: StringFieldUpdateOperationsInput | string
    task?: StringFieldUpdateOperationsInput | string
    inputTokens?: IntFieldUpdateOperationsInput | number
    outputTokens?: IntFieldUpdateOperationsInput | number
    cost?: FloatFieldUpdateOperationsInput | number
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    status?: StringFieldUpdateOperationsInput | string
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type AiAnalysisUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    eventId?: StringFieldUpdateOperationsInput | string
    model?: StringFieldUpdateOperationsInput | string
    task?: StringFieldUpdateOperationsInput | string
    inputTokens?: IntFieldUpdateOperationsInput | number
    outputTokens?: IntFieldUpdateOperationsInput | number
    cost?: FloatFieldUpdateOperationsInput | number
    durationMs?: NullableIntFieldUpdateOperationsInput | number | null
    status?: StringFieldUpdateOperationsInput | string
    errorMsg?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: StringFieldUpdateOperationsInput | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type FloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type EventCountOrderByAggregateInput = {
    id?: SortOrder
    rawItemId?: SortOrder
    titleOriginal?: SortOrder
    titleCn?: SortOrder
    titleLang?: SortOrder
    summaryOriginal?: SortOrder
    summaryCn?: SortOrder
    contentOriginal?: SortOrder
    contentCn?: SortOrder
    contentHint?: SortOrder
    contentType?: SortOrder
    url?: SortOrder
    permalink?: SortOrder
    sourceId?: SortOrder
    sourceName?: SortOrder
    sourceLevel?: SortOrder
    sourceCountry?: SortOrder
    sourceFeed?: SortOrder
    sourceDesc?: SortOrder
    category?: SortOrder
    subCategory?: SortOrder
    tags?: SortOrder
    affectedRegions?: SortOrder
    scores?: SortOrder
    finalScore?: SortOrder
    importance?: SortOrder
    aiStatus?: SortOrder
    aiModel?: SortOrder
    aiTranslateModel?: SortOrder
    aiReason?: SortOrder
    aiCost?: SortOrder
    aiAnalyzedAt?: SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    publishedAt?: SortOrder
    crawledAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    coverUrl?: SortOrder
    clusterId?: SortOrder
    clusterSize?: SortOrder
  }

  export type EventAvgOrderByAggregateInput = {
    finalScore?: SortOrder
    importance?: SortOrder
    aiCost?: SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    clusterSize?: SortOrder
  }

  export type EventMaxOrderByAggregateInput = {
    id?: SortOrder
    rawItemId?: SortOrder
    titleOriginal?: SortOrder
    titleCn?: SortOrder
    titleLang?: SortOrder
    summaryOriginal?: SortOrder
    summaryCn?: SortOrder
    contentOriginal?: SortOrder
    contentCn?: SortOrder
    contentHint?: SortOrder
    contentType?: SortOrder
    url?: SortOrder
    permalink?: SortOrder
    sourceId?: SortOrder
    sourceName?: SortOrder
    sourceLevel?: SortOrder
    sourceCountry?: SortOrder
    sourceFeed?: SortOrder
    sourceDesc?: SortOrder
    category?: SortOrder
    subCategory?: SortOrder
    tags?: SortOrder
    affectedRegions?: SortOrder
    scores?: SortOrder
    finalScore?: SortOrder
    importance?: SortOrder
    aiStatus?: SortOrder
    aiModel?: SortOrder
    aiTranslateModel?: SortOrder
    aiReason?: SortOrder
    aiCost?: SortOrder
    aiAnalyzedAt?: SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    publishedAt?: SortOrder
    crawledAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    coverUrl?: SortOrder
    clusterId?: SortOrder
    clusterSize?: SortOrder
  }

  export type EventMinOrderByAggregateInput = {
    id?: SortOrder
    rawItemId?: SortOrder
    titleOriginal?: SortOrder
    titleCn?: SortOrder
    titleLang?: SortOrder
    summaryOriginal?: SortOrder
    summaryCn?: SortOrder
    contentOriginal?: SortOrder
    contentCn?: SortOrder
    contentHint?: SortOrder
    contentType?: SortOrder
    url?: SortOrder
    permalink?: SortOrder
    sourceId?: SortOrder
    sourceName?: SortOrder
    sourceLevel?: SortOrder
    sourceCountry?: SortOrder
    sourceFeed?: SortOrder
    sourceDesc?: SortOrder
    category?: SortOrder
    subCategory?: SortOrder
    tags?: SortOrder
    affectedRegions?: SortOrder
    scores?: SortOrder
    finalScore?: SortOrder
    importance?: SortOrder
    aiStatus?: SortOrder
    aiModel?: SortOrder
    aiTranslateModel?: SortOrder
    aiReason?: SortOrder
    aiCost?: SortOrder
    aiAnalyzedAt?: SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    publishedAt?: SortOrder
    crawledAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    coverUrl?: SortOrder
    clusterId?: SortOrder
    clusterSize?: SortOrder
  }

  export type EventSumOrderByAggregateInput = {
    finalScore?: SortOrder
    importance?: SortOrder
    aiCost?: SortOrder
    selected?: SortOrder
    isLead?: SortOrder
    isSocial?: SortOrder
    readCount?: SortOrder
    likeCount?: SortOrder
    clusterSize?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type FloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type SourceCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    nameEn?: SortOrder
    type?: SortOrder
    country?: SortOrder
    region?: SortOrder
    level?: SortOrder
    enabled?: SortOrder
    endpoints?: SortOrder
    config?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SourceAvgOrderByAggregateInput = {
    enabled?: SortOrder
  }

  export type SourceMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    nameEn?: SortOrder
    type?: SortOrder
    country?: SortOrder
    region?: SortOrder
    level?: SortOrder
    enabled?: SortOrder
    endpoints?: SortOrder
    config?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SourceMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    nameEn?: SortOrder
    type?: SortOrder
    country?: SortOrder
    region?: SortOrder
    level?: SortOrder
    enabled?: SortOrder
    endpoints?: SortOrder
    config?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SourceSumOrderByAggregateInput = {
    enabled?: SortOrder
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type CrawlLogCountOrderByAggregateInput = {
    id?: SortOrder
    sourceId?: SortOrder
    startedAt?: SortOrder
    finishedAt?: SortOrder
    status?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    errorMsg?: SortOrder
    durationMs?: SortOrder
    createdAt?: SortOrder
  }

  export type CrawlLogAvgOrderByAggregateInput = {
    id?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    durationMs?: SortOrder
  }

  export type CrawlLogMaxOrderByAggregateInput = {
    id?: SortOrder
    sourceId?: SortOrder
    startedAt?: SortOrder
    finishedAt?: SortOrder
    status?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    errorMsg?: SortOrder
    durationMs?: SortOrder
    createdAt?: SortOrder
  }

  export type CrawlLogMinOrderByAggregateInput = {
    id?: SortOrder
    sourceId?: SortOrder
    startedAt?: SortOrder
    finishedAt?: SortOrder
    status?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    errorMsg?: SortOrder
    durationMs?: SortOrder
    createdAt?: SortOrder
  }

  export type CrawlLogSumOrderByAggregateInput = {
    id?: SortOrder
    itemsTotal?: SortOrder
    itemsNew?: SortOrder
    itemsDup?: SortOrder
    durationMs?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type AiAnalysisCountOrderByAggregateInput = {
    id?: SortOrder
    eventId?: SortOrder
    model?: SortOrder
    task?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrder
    status?: SortOrder
    errorMsg?: SortOrder
    createdAt?: SortOrder
  }

  export type AiAnalysisAvgOrderByAggregateInput = {
    id?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrder
  }

  export type AiAnalysisMaxOrderByAggregateInput = {
    id?: SortOrder
    eventId?: SortOrder
    model?: SortOrder
    task?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrder
    status?: SortOrder
    errorMsg?: SortOrder
    createdAt?: SortOrder
  }

  export type AiAnalysisMinOrderByAggregateInput = {
    id?: SortOrder
    eventId?: SortOrder
    model?: SortOrder
    task?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrder
    status?: SortOrder
    errorMsg?: SortOrder
    createdAt?: SortOrder
  }

  export type AiAnalysisSumOrderByAggregateInput = {
    id?: SortOrder
    inputTokens?: SortOrder
    outputTokens?: SortOrder
    cost?: SortOrder
    durationMs?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type FloatFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedFloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}